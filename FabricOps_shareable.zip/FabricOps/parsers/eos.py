from __future__ import annotations

from typing import Any, Dict, List
import re

from utils.formatting import clean, format_duration, format_speed

TABLE_KEYS = [
    "interfaces", "interface_errors", "vlans", "bgp", "ospf", "mlag", "port_channels", "lldp",
    "vrfs", "ip_interfaces", "routes", "vxlan", "evpn", "command_failures", "command_outputs",
    "device_profiles", "device_details", "l2_summary", "l3_summary", "access_summary", "overlay_summary"
]



ROLE_ORDER = {"router": 0, "spine": 1, "leaf": 2, "memleaf": 3, "host": 4, "other": 9}


def _device_group(name: Any) -> str:
    n = str(name or "").lower()
    if "router" in n:
        return "router"
    if "spine" in n:
        return "spine"
    if "memleaf" in n:
        return "memleaf"
    if n.startswith("leaf"):
        return "leaf"
    if "host" in n:
        return "host"
    return "other"


def _natural_key(value: Any) -> tuple:
    text = str(value or "").lower()
    parts = re.split(r"(\d+)", text)
    return tuple(int(p) if p.isdigit() else p for p in parts)


def _device_sort_key(name: Any) -> tuple:
    return (ROLE_ORDER.get(_device_group(name), 9), _natural_key(name))


def _sort_table_rows(tables: Dict[str, List[Dict[str, Any]]]) -> None:
    for key, rows in tables.items():
        rows.sort(key=lambda r: (_device_sort_key(r.get("Device", "")), _natural_key(r.get("Interface") or r.get("VLAN") or r.get("Neighbor") or r.get("Port-Channel") or r.get("VRF") or r.get("Prefix") or r.get("Command") or "")))

def build_technical_tables(device_results: List[Dict[str, Any]]) -> Dict[str, List[Dict[str, Any]]]:
    tables: Dict[str, List[Dict[str, Any]]] = {k: [] for k in TABLE_KEYS}

    for item in device_results:
        dev = item.get("device", {}) or {}
        device = dev.get("name", "UNKNOWN")
        outputs = item.get("outputs") or {}
        formats = item.get("output_formats") or {}

        if item.get("transport_note"):
            tables["command_failures"].append({"Device": device, "Command": "transport", "Reason": item["transport_note"]})

        if item.get("error") and not item.get("reachable"):
            tables["command_failures"].append({"Device": device, "Command": "eAPI collection", "Reason": item.get("error", "Unknown eAPI error")})

        for row in item.get("command_status", []) or []:
            if row.get("Status") != "OK":
                tables["command_failures"].append({"Device": device, "Command": clean(row.get("Command")), "Reason": clean(row.get("Error"))})

        for cmd, out in outputs.items():
            tables["command_outputs"].append({"Device": device, "Command": cmd, "Format": formats.get(cmd, "unknown"), "Preview": preview(out)})

        _parse_interfaces(device, outputs.get("show interfaces status"), tables)
        _parse_interface_errors(device, outputs.get("show interfaces counters errors"), tables)
        _parse_vlans(device, outputs.get("show vlan"), tables)
        _parse_bgp(device, outputs.get("show ip bgp summary"), tables["bgp"], afi="IPv4")
        _parse_bgp(device, outputs.get("show bgp evpn summary"), tables["evpn"], afi="EVPN")
        _parse_ospf(device, outputs.get("show ip ospf neighbor"), tables)
        _parse_mlag(device, outputs.get("show mlag") or outputs.get("show mlag interfaces"), tables)
        _parse_port_channels(device, outputs.get("show port-channel summary"), tables)
        _parse_lldp(device, outputs.get("show lldp neighbors detail") or outputs.get("show lldp neighbors"), tables)
        _parse_vrfs(device, outputs.get("show vrf"), tables)
        _parse_ip_interfaces(device, outputs.get("show ip interface brief"), tables)
        _parse_routes(device, outputs.get("show ip route"), tables)
        _parse_vxlan(device, outputs, tables)

    _build_device_profiles(tables, device_results)
    _sort_table_rows(tables)
    return tables


def preview(x: Any, limit: int = 420) -> str:
    if x is None:
        return ""
    s = x if isinstance(x, str) else str(x)
    return s.replace("\n", " | ")[:limit]



def clean_lldp_port(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, dict):
        for k in ("interfaceId_v2", "interfaceId", "neighborPortId", "portId", "name", "interface", "value"):
            if value.get(k):
                return clean_lldp_port(value.get(k))
        return ""
    if isinstance(value, list):
        return ", ".join(clean_lldp_port(x) for x in value if clean_lldp_port(x))
    text = str(value).strip().strip("'").strip('"')
    if text.startswith("{") and "interfaceId" in text:
        import re as _re
        for pat in [r"'interfaceId_v2':\s*'([^']+)'", r'"interfaceId_v2":\s*"([^"]+)"', r"'interfaceId':\s*'\"?([^'\"]+)\"?'", r'"interfaceId":\s*"\\?"?([^"}]+)']:
            m = _re.search(pat, text)
            if m:
                return clean_lldp_port(m.group(1))
        return ""
    return text

def _object_rows(obj: Any, name_key: str) -> List[Dict[str, Any]]:
    if isinstance(obj, list):
        return [x for x in obj if isinstance(x, dict)]
    if isinstance(obj, dict):
        return [{name_key: k, **(v if isinstance(v, dict) else {"value": v})} for k, v in obj.items()]
    return []


def _deep_find(value: Any, keys: List[str]) -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []
    seen = set()

    def walk(x: Any) -> None:
        if id(x) in seen:
            return
        if isinstance(x, (dict, list)):
            seen.add(id(x))
        if isinstance(x, list):
            for c in x:
                walk(c)
            return
        if not isinstance(x, dict):
            return
        row: Dict[str, Any] = {}
        hit = False
        for key in keys:
            if key in x and not isinstance(x[key], (dict, list)):
                row[key] = x[key]
                hit = True
        if hit:
            rows.append(row)
        for c in x.values():
            walk(c)

    walk(value)
    return rows


def _parse_interfaces(device: str, data: Any, tables: Dict[str, List[Dict[str, Any]]]) -> None:
    if isinstance(data, dict):
        rows = _object_rows(data.get("interfaceStatuses") or data.get("interfaces"), "Interface")
        for r in rows:
            interface = clean(r.get("Interface") or r.get("name") or r.get("interface"))
            vlan_info = r.get("vlanInformation") or {}
            row = {
                "Device": device,
                "Interface": interface,
                "Status": clean(r.get("linkStatus") or r.get("status") or r.get("interfaceStatus") or r.get("lineProtocolStatus")),
                "VLAN": clean(vlan_info.get("vlanId") or r.get("vlan") or r.get("accessVlan")),
                "Mode": _normalize_mode(r.get("mode") or r.get("switchportMode") or vlan_info.get("interfaceMode"), interface),
                "Speed": format_speed(r.get("bandwidth") or r.get("speed")),
                "Description": clean(r.get("description"), allow_na=True),
            }
            tables["interfaces"].append(row)
        return

    if isinstance(data, str):
        for line in data.splitlines():
            if not re.match(r"^(Et|Ethernet|Ma|Management|Po|Port-Channel|Vl|Vlan|Vxlan)\S+", line.strip()):
                continue
            parts = line.split()
            if len(parts) >= 3:
                status_idx = next((i for i, p in enumerate(parts) if p.lower() in ["connected", "notconnect", "disabled", "errdisabled", "inactive", "up", "down"]), 2)
                tables["interfaces"].append({
                    "Device": device,
                    "Interface": parts[0],
                    "Status": parts[status_idx],
                    "VLAN": clean(parts[status_idx + 1] if len(parts) > status_idx + 1 else ""),
                    "Mode": "",
                    "Speed": "",
                    "Description": clean(" ".join(parts[1:status_idx]), allow_na=True),
                })


def _normalize_mode(mode: Any, interface: str = "") -> str:
    text = clean(mode).lower()
    if not text:
        if str(interface).lower().startswith(("management", "loopback", "vlan")):
            return "routed"
        return ""
    aliases = {"bridged": "access/bridged", "access": "access", "routed": "routed", "trunk": "trunk"}
    return aliases.get(text, text)


def _parse_interface_errors(device: str, data: Any, tables: Dict[str, List[Dict[str, Any]]]) -> None:
    if not isinstance(data, dict) or not isinstance(data.get("interfaces"), dict):
        return
    for interface, counters in data["interfaces"].items():
        if not isinstance(counters, dict):
            continue
        input_errors = counters.get("inputErrors", counters.get("inErrors", 0))
        output_errors = counters.get("outputErrors", counters.get("outErrors", 0))
        crc = counters.get("fcsErrors", counters.get("crcErrors", 0))
        discards = counters.get("inputDiscards", 0) or counters.get("outputDiscards", 0)
        try:
            has_error = int(input_errors or 0) or int(output_errors or 0) or int(crc or 0) or int(discards or 0)
        except Exception:
            has_error = bool(input_errors or output_errors or crc or discards)
        if has_error:
            tables["interface_errors"].append({
                "Device": device,
                "Interface": interface,
                "Input Errors": clean(input_errors),
                "Output Errors": clean(output_errors),
                "CRC/FCS": clean(crc),
                "Discards": clean(discards),
            })


def _parse_vlans(device: str, data: Any, tables: Dict[str, List[Dict[str, Any]]]) -> None:
    if isinstance(data, dict) and isinstance(data.get("vlans"), dict):
        for vlan_id, vlan in data["vlans"].items():
            if not isinstance(vlan, dict):
                continue
            row = {
                "Device": device,
                "VLAN": str(vlan_id),
                "Name": clean(vlan.get("name") or vlan.get("vlanName")),
                "Status": clean(vlan.get("status") or "active"),
                "Interfaces": ", ".join(vlan.get("interfaces", [])) if isinstance(vlan.get("interfaces"), list) and vlan.get("interfaces") else "",
            }
            tables["vlans"].append(row)
    elif isinstance(data, str):
        for line in data.splitlines():
            if re.match(r"^\d+\s+", line.strip()):
                p = line.split()
                tables["vlans"].append({"Device": device, "VLAN": p[0], "Name": p[1] if len(p) > 1 else "", "Status": p[2] if len(p) > 2 else "", "Interfaces": ""})


def _parse_bgp(device: str, data: Any, rows: List[Dict[str, Any]], afi: str, vrf: str = "default", seen=None) -> None:
    if seen is None:
        seen = set()
    if not data:
        return
    if isinstance(data, dict):
        if id(data) in seen:
            return
        seen.add(id(data))
        if isinstance(data.get("vrfs"), dict):
            for vrf_name, vrf_obj in data["vrfs"].items():
                _parse_bgp(device, vrf_obj, rows, afi, str(vrf_name), seen)
        if isinstance(data.get("peers"), dict):
            for neighbor, peer in data["peers"].items():
                if not isinstance(peer, dict):
                    continue
                rows.append({
                    "Device": device,
                    "AFI": afi,
                    "VRF": vrf,
                    "Neighbor": neighbor,
                    "ASN": clean(peer.get("asn") or peer.get("peerAsn") or peer.get("remoteAs")),
                    "State": clean(peer.get("peerState") or peer.get("state") or peer.get("connectionState")),
                    "Prefixes": clean(peer.get("prefixAccepted") or peer.get("prefixReceived") or peer.get("receivedPrefixes") or peer.get("prefixesReceived")),
                    "Uptime": format_duration(peer.get("upDownTime") or peer.get("establishedTime") or peer.get("upTime") or peer.get("lastEstablishedTime")),
                })
        return

    if isinstance(data, str):
        for line in data.splitlines():
            if re.match(r"^(\d+\.\d+\.\d+\.\d+|[0-9a-fA-F:]+)\s+", line.strip()):
                parts = line.split()
                state = parts[-1] if parts else ""
                rows.append({
                    "Device": device,
                    "AFI": afi,
                    "VRF": vrf,
                    "Neighbor": parts[0],
                    "ASN": parts[2] if len(parts) > 2 else "",
                    "State": state,
                    "Prefixes": state if state.isdigit() else "",
                    "Uptime": format_duration(parts[-2] if len(parts) > 2 else ""),
                })


def _parse_ospf(device: str, data: Any, tables: Dict[str, List[Dict[str, Any]]]) -> None:
    if isinstance(data, str):
        for line in data.splitlines():
            if re.match(r"^\d+\.\d+\.\d+\.\d+", line.strip()):
                p = line.split()
                tables["ospf"].append({"Device": device, "Neighbor": p[0], "State": p[2] if len(p) > 2 else "", "Interface": p[-1] if p else "", "Area": ""})
    else:
        for r in _deep_find(data, ["routerId", "state", "interfaceName", "adjacencyState", "area"]):
            tables["ospf"].append({
                "Device": device,
                "Neighbor": clean(r.get("routerId")),
                "State": clean(r.get("state") or r.get("adjacencyState")),
                "Interface": clean(r.get("interfaceName")),
                "Area": clean(r.get("area")),
            })


def _parse_mlag(device: str, data: Any, tables: Dict[str, List[Dict[str, Any]]]) -> None:
    """Parse MLAG only when there is real MLAG evidence.

    EOS may return a disabled/not-configured MLAG response on routers or pure
    Layer-3 devices. That must not create an MLAG row, because later health
    logic would incorrectly judge those devices as needing MLAG.
    """
    def has_real_mlag_dict(d: Dict[str, Any]) -> bool:
        values = {
            "state": clean(d.get("state")),
            "peer": clean(d.get("peerAddress") or d.get("peerLink")),
            "local": clean(d.get("localInterface")),
            "peer_link": clean(d.get("peerLink") or d.get("peerLinkStatus")),
            "sanity": clean(d.get("configSanity") or d.get("consistency")),
            "domain": clean(d.get("domainId") or d.get("mlagDomain") or d.get("domain")),
        }
        combined = " ".join(values.values()).lower()
        # If the only evidence is disabled/not configured, skip it.
        if any(x in combined for x in ["not configured", "not enabled", "mlag disabled", "disabled"]) and not (values["peer"] or values["local"] or values["domain"]):
            return False
        # Strong MLAG evidence: peer/local/domain/peer-link or explicit active state.
        return bool(values["peer"] or values["local"] or values["domain"] or ("active" in combined and "mlag" in str(d).lower()))

    if isinstance(data, dict):
        if not has_real_mlag_dict(data):
            return
        tables["mlag"].append({
            "Device": device,
            "State": clean(data.get("state") or data.get("peerLinkStatus") or data.get("negStatus") or "present"),
            "Peer": clean(data.get("peerAddress") or data.get("peerLink")),
            "Local Intf": clean(data.get("localInterface")),
            "Peer Link": clean(data.get("peerLink") or data.get("peerLinkStatus")),
            "Consistency": clean(data.get("configSanity") or data.get("consistency")),
        })
    elif isinstance(data, str) and data.strip():
        lower = data.lower()
        if any(x in lower for x in ["not configured", "not enabled", "mlag is disabled", "mlag disabled"]) and "peer-link" not in lower and "local-interface" not in lower:
            return
        # Text evidence should mention actual MLAG configuration/state, not only a disabled feature.
        if "mlag" not in lower and "peer-link" not in lower and "local-interface" not in lower:
            return
        state = "present"
        for line in data.splitlines():
            if "state" in line.lower() or "status" in line.lower():
                state = line.strip()
                break
        tables["mlag"].append({"Device": device, "State": state, "Peer": "", "Local Intf": "", "Peer Link": "", "Consistency": ""})


def _parse_port_channels(device: str, data: Any, tables: Dict[str, List[Dict[str, Any]]]) -> None:
    if isinstance(data, str):
        for line in data.splitlines():
            if re.search(r"Port-Channel|Po\d+", line):
                tables["port_channels"].append({"Device": device, "Port-Channel": line.split()[0] if line.split() else "", "State": line.strip(), "Protocol": "", "Active Ports": "", "Inactive Ports": ""})
    else:
        for r in _deep_find(data, ["name", "interface", "state", "protocol", "activePorts", "inactivePorts"]):
            tables["port_channels"].append({
                "Device": device,
                "Port-Channel": clean(r.get("name") or r.get("interface")),
                "State": clean(r.get("state")),
                "Protocol": clean(r.get("protocol")),
                "Active Ports": ", ".join(r.get("activePorts", [])) if isinstance(r.get("activePorts"), list) else clean(r.get("activePorts")),
                "Inactive Ports": ", ".join(r.get("inactivePorts", [])) if isinstance(r.get("inactivePorts"), list) else clean(r.get("inactivePorts")),
            })


def _parse_lldp(device: str, data: Any, tables: Dict[str, List[Dict[str, Any]]]) -> None:
    def add(local_intf: Any, neighbor: Any, neighbor_port: Any) -> None:
        ni = clean(neighbor)
        if not ni:
            return
        # Keep the short hostname when EOS returns FQDN/system descriptions.
        ni = ni.split()[0].split(".")[0]
        tables["lldp"].append({
            "Device": device,
            "Interface": clean_lldp_port(local_intf),
            "Neighbor": ni,
            "Neighbor Port": clean_lldp_port(neighbor_port),
        })

    if isinstance(data, str):
        for line in data.splitlines():
            if re.match(r"^(Et|Ethernet|Ma|Management|Po|Port-Channel)\S+", line.strip()):
                p = line.split()
                add(p[0], p[1] if len(p) > 1 else "", p[2] if len(p) > 2 else "")
        return

    if not isinstance(data, dict):
        return

    # Common EOS JSON shapes:
    # 1) {"lldpNeighbors": [{"port":"Ethernet1", "neighborDevice":"spine1", "neighborPort":"Ethernet3"}]}
    # 2) {"lldpNeighbors": {"Ethernet1": {"lldpNeighborInfo": [{"systemName":"spine1", "neighborInterfaceInfo":"Ethernet3"}]}}}
    neighbor_blob = data.get("lldpNeighbors") or data.get("neighbors") or data

    def parse_entry(entry: Any, context_port: str = "") -> None:
        if isinstance(entry, list):
            for child in entry:
                parse_entry(child, context_port)
            return
        if not isinstance(entry, dict):
            return
        local_intf = (
            entry.get("interface") or entry.get("port") or entry.get("localPort") or
            entry.get("localInterface") or entry.get("portName") or context_port
        )
        neighbor = (
            entry.get("neighborDevice") or entry.get("neighborDeviceId") or entry.get("systemName") or
            entry.get("neighborName") or entry.get("chassisId") or entry.get("hostname")
        )
        neighbor_port = (
            entry.get("neighborPort") or entry.get("neighborPortId") or entry.get("portId") or
            entry.get("remotePort") or entry.get("neighborInterfaceInfo") or entry.get("interfaceInfo") or entry.get("portDescription")
        )
        if neighbor:
            add(local_intf, neighbor, neighbor_port)
        for key in ("lldpNeighborInfo", "neighbors", "details", "entries"):
            if key in entry:
                parse_entry(entry[key], clean(local_intf) or context_port)

    if isinstance(neighbor_blob, list):
        parse_entry(neighbor_blob)
    elif isinstance(neighbor_blob, dict):
        for local_intf, entry in neighbor_blob.items():
            parse_entry(entry, str(local_intf))

def _parse_vrfs(device: str, data: Any, tables: Dict[str, List[Dict[str, Any]]]) -> None:
    if isinstance(data, dict) and isinstance(data.get("vrfs"), dict):
        for name, vrf in data["vrfs"].items():
            tables["vrfs"].append({
                "Device": device,
                "VRF": str(name),
                "RD": clean(vrf.get("routeDistinguisher")) if isinstance(vrf, dict) else "",
                "Interfaces": ", ".join(vrf.get("interfaces", [])) if isinstance(vrf, dict) and isinstance(vrf.get("interfaces"), list) else "",
            })
    elif isinstance(data, str):
        for line in data.splitlines():
            if line.strip() and not line.lower().startswith(("vrf", "---")):
                tables["vrfs"].append({"Device": device, "VRF": line.split()[0], "RD": "", "Interfaces": ""})


def _parse_ip_interfaces(device: str, data: Any, tables: Dict[str, List[Dict[str, Any]]]) -> None:
    if isinstance(data, str):
        for line in data.splitlines():
            if re.match(r"^(Et|Ethernet|Ma|Management|Vl|Vlan|Lo|Loopback)\S+", line.strip()):
                p = line.split()
                tables["ip_interfaces"].append({"Device": device, "Interface": p[0], "Address": p[1] if len(p) > 1 else "", "Status": p[2] if len(p) > 2 else ""})
    else:
        for r in _deep_find(data, ["name", "interface", "interfaceAddress", "ipAddress", "lineProtocolStatus", "interfaceStatus"]):
            tables["ip_interfaces"].append({
                "Device": device,
                "Interface": clean(r.get("name") or r.get("interface")),
                "Address": clean(r.get("interfaceAddress") or r.get("ipAddress")),
                "Status": clean(r.get("lineProtocolStatus") or r.get("interfaceStatus")),
            })


def _parse_routes(device: str, data: Any, tables: Dict[str, List[Dict[str, Any]]]) -> None:
    if isinstance(data, dict) and isinstance(data.get("vrfs"), dict):
        for vrf_name, vrf in data["vrfs"].items():
            routes = vrf.get("routes") if isinstance(vrf, dict) else {}
            if isinstance(routes, dict):
                for prefix, route in list(routes.items())[:80]:
                    vias = route.get("vias", []) if isinstance(route, dict) else []
                    nh = ", ".join(str(v.get("nexthopAddr") or v.get("interface") or "") for v in vias if isinstance(v, dict)) if isinstance(vias, list) else ""
                    tables["routes"].append({"Device": device, "VRF": str(vrf_name), "Prefix": prefix, "Protocol": clean(route.get("routeType") or route.get("sourceProtocol")), "Next Hop": clean(nh)})
    elif isinstance(data, str):
        for line in data.splitlines():
            if re.match(r"^[A-Z][ A-Z]?\s+", line.strip()):
                p = line.split()
                tables["routes"].append({"Device": device, "VRF": "default", "Prefix": p[1] if len(p) > 1 else line[:40], "Protocol": p[0], "Next Hop": line.strip()[:180]})


def _parse_vxlan(device: str, outputs: Dict[str, Any], tables: Dict[str, List[Dict[str, Any]]]) -> None:
    vtep = outputs.get("show vxlan vtep")
    vx_cmd = next((c for c in outputs if c.lower().startswith("show interfaces vxlan ")), "")
    if vtep or vx_cmd:
        raw = str(outputs.get(vx_cmd) or vtep or "")
        tables["vxlan"].append({"Device": device, "VXLAN Interface": vx_cmd.replace("show interfaces ", "") if vx_cmd else "", "VTEP": preview(vtep, 160) if vtep else "", "Status": "DOWN" if "down" in raw.lower() else "PRESENT"})


def _build_device_profiles(tables: Dict[str, List[Dict[str, Any]]], device_results: List[Dict[str, Any]]) -> None:
    device_names = sorted({(r.get("device") or {}).get("name", "UNKNOWN") for r in device_results}, key=_device_sort_key)
    for device in device_names:
        interfaces = [r for r in tables["interfaces"] if r.get("Device") == device]
        vlans = [r for r in tables["vlans"] if r.get("Device") == device and r.get("VLAN") and str(r.get("VLAN")) not in {"1", "default"}]
        bgp = [r for r in tables["bgp"] if r.get("Device") == device]
        ospf = [r for r in tables["ospf"] if r.get("Device") == device]
        mlag = [r for r in tables["mlag"] if r.get("Device") == device]
        vrfs = [r for r in tables["vrfs"] if r.get("Device") == device]
        vxlan = [r for r in tables["vxlan"] if r.get("Device") == device]
        evpn = [r for r in tables["evpn"] if r.get("Device") == device]

        l2_intfs = [r for r in interfaces if str(r.get("Mode", "")).lower() in {"access", "access/bridged", "trunk", "bridged"} or r.get("VLAN")]
        l3_intfs = [r for r in interfaces if str(r.get("Mode", "")).lower() == "routed"]
        access_intfs = [r for r in interfaces if r.get("VLAN") and not str(r.get("Interface", "")).lower().startswith("port-channel")]
        trunk_intfs = [r for r in interfaces if str(r.get("Mode", "")).lower() == "trunk"]

        feature_labels = []
        if l2_intfs or vlans or mlag:
            feature_labels.append("Layer 2")
        if l3_intfs or bgp or ospf or vrfs:
            feature_labels.append("Layer 3")
        if access_intfs:
            feature_labels.append("Access")
        if vxlan or evpn:
            feature_labels.append("Overlay")
        if not feature_labels:
            feature_labels.append("Inventory only")

        profile = {
            "Device": device,
            "Fabric Role": " / ".join(feature_labels),
            "Layer 2": _count_summary({"VLANs": len(vlans), "MLAG": len(mlag), "Trunks": len(trunk_intfs)}),
            "Layer 3": _count_summary({"Routed Interfaces": len(l3_intfs), "BGP Peers": len(bgp), "OSPF Peers": len(ospf), "VRFs": len(vrfs)}),
            "Access": _count_summary({"Access Ports": len(access_intfs)}),
            "Overlay": _count_summary({"VXLAN": len(vxlan), "EVPN Peers": len(evpn)}),
        }
        tables["device_profiles"].append(profile)

        if l2_intfs:
            tables["l2_summary"].append({"Device": device, "VLANs": ", ".join(_vlan_label(v) for v in vlans if v.get("VLAN")), "Trunks": ", ".join(r.get("Interface", "") for r in trunk_intfs), "MLAG": "present" if mlag else ""})
        if l3_intfs or bgp or ospf:
            tables["l3_summary"].append({"Device": device, "Routed Interfaces": ", ".join(r.get("Interface", "") for r in l3_intfs), "BGP Peers": str(len(bgp)) if bgp else "", "OSPF Peers": str(len(ospf)) if ospf else ""})
        if access_intfs:
            tables["access_summary"].append({"Device": device, "Access Ports": ", ".join(f"{r.get('Interface')} VLAN {r.get('VLAN')}" for r in access_intfs), "Descriptions": ", ".join(r.get("Description", "") for r in access_intfs if r.get("Description") and r.get("Description") != "N/A")})
        if vxlan or evpn:
            tables["overlay_summary"].append({"Device": device, "VXLAN": "present" if vxlan else "", "EVPN Peers": str(len(evpn)) if evpn else ""})


def _count_summary(counts: Dict[str, int]) -> str:
    parts = [f"{name}: {count}" for name, count in counts.items() if count]
    return "; ".join(parts)


def _vlan_label(row: Dict[str, Any]) -> str:
    name = row.get("Name")
    return f"{row.get('VLAN')} ({name})" if name else str(row.get("VLAN"))
