
from __future__ import annotations
from typing import Dict, List

HEALTH_PROFILES: Dict[str, List[str]] = {
    "Quick Health Check": [
        "show hostname", "show version", "show inventory",
        "show interfaces status", "show ip interface brief", "show lldp neighbors",
        "show port-channel summary", "show mlag", "show ip bgp summary", "show vlan",
    ],
    "Complete Fabric Health": [
        "show hostname", "show version", "show inventory", "show users", "show clock", "show reload cause",
        "show interfaces", "show interfaces status", "show interfaces description", "show interfaces counters errors",
        "show ip interface brief", "show lldp neighbors", "show lldp neighbors detail",
        "show port-channel summary", "show lacp neighbor", "show lacp counters",
        "show mlag", "show mlag interfaces", "show mlag config-sanity",
        "show vlan", "show interfaces switchport", "show spanning-tree", "show spanning-tree summary",
        "show mac address-table", "show vrf", "show ip virtual-router", "show ip route", "show ip route summary",
        "show ip ospf neighbor", "show ip ospf interface", "show ip ospf database",
        "show ip bgp summary", "show ip bgp neighbors", "show bgp evpn summary", "show running-config",
    ],
    "VXLAN / EVPN Validation": [
        "show hostname", "show version", "show inventory", "show interfaces status", "show interfaces counters errors",
        "show ip interface brief", "show lldp neighbors detail", "show port-channel summary",
        "show mlag", "show mlag interfaces", "show vlan", "show interfaces switchport",
        "show vrf", "show ip virtual-router", "show ip route", "show ip bgp summary", "show bgp evpn summary",
        "show vxlan vtep", "show vxlan address-table", "show vxlan flood vtep",
        "show bgp evpn route-type mac-ip", "show bgp evpn route-type imet", "show bgp evpn route-type ip-prefix ipv4",
        "show running-config",
    ],
    "Deep Diagnostics": [
        "show hostname", "show version", "show inventory", "show users", "show clock", "show reload cause",
        "show system memory", "show processes top once", "show logging last 100",
        "show interfaces", "show interfaces status", "show interfaces description", "show interfaces counters", "show interfaces counters errors",
        "show interfaces transceiver", "show ip interface brief", "show lldp neighbors detail",
        "show port-channel summary", "show lacp neighbor", "show lacp counters",
        "show mlag", "show mlag interfaces", "show mlag config-sanity",
        "show vlan", "show interfaces switchport", "show spanning-tree", "show spanning-tree summary",
        "show mac address-table", "show vrf", "show ip virtual-router", "show ip route", "show ip route summary",
        "show ip ospf neighbor", "show ip ospf interface", "show ip ospf database",
        "show ip bgp summary", "show ip bgp neighbors", "show bgp evpn summary",
        "show vxlan vtep", "show vxlan address-table", "show vxlan flood vtep", "show running-config",
    ],
}

def build_commands(profile: str, vxlan_interface: str = "1", vnis: str = "", vlans: str = "", vrfs: str = "") -> List[str]:
    commands = list(HEALTH_PROFILES.get(profile, HEALTH_PROFILES["Complete Fabric Health"]))
    if profile in {"VXLAN / EVPN Validation", "Deep Diagnostics"}:
        commands.append(f"show interfaces vxlan {vxlan_interface or '1'}")
        for vni in _split_csv(vnis):
            commands.append(f"show bgp evpn route-type mac-ip vni {vni}")
            commands.append(f"show bgp evpn route-type mac-ip vni {vni} detail")
        for vlan in _split_csv(vlans):
            commands.append(f"show l2Rib output vlan {vlan}")
        for vrf in _split_csv(vrfs):
            commands.append(f"show ip virtual-router vrf {vrf}")
    seen, final = set(), []
    for c in commands:
        c = c.strip()
        if not c or c in seen:
            continue
        validate_show_command(c)
        seen.add(c); final.append(c)
    return final

def _split_csv(value: str) -> List[str]:
    return [x.strip() for x in (value or '').replace('\n', ',').split(',') if x.strip()]

def validate_show_command(command: str) -> None:
    low = command.strip().lower()
    if not low.startswith('show ') or any(x in command for x in [';', '\n', '\r']):
        raise ValueError(f"Unsafe command rejected: {command}")
