from __future__ import annotations

import html
from datetime import datetime
from typing import Any, Dict, List


def esc(value: Any) -> str:
    if value is None:
        return ""
    text = str(value)
    if text.lower() in {"none", "null", "[]", "{}"}:
        return ""
    return html.escape(text)


def badge(value: Any) -> str:
    text = str(value or "").upper()
    cls = "neutral"
    if text == "GREEN" or text in {"ACTIVE", "ESTABLISHED", "CONNECTED", "UP", "FULL", "PRESENT"}:
        cls = "green"
    elif text == "YELLOW" or text in {"WARNING", "ATTENTION", "IDLE", "ACTIVE"}:
        cls = "yellow"
    elif text == "RED" or text in {"CRITICAL", "DOWN", "FAILED"}:
        cls = "red"
    return f"<span class='badge {cls}'>{esc(value)}</span>"


def table(rows: List[Dict[str, Any]], columns: List[str] | None = None, max_rows: int | None = None) -> str:
    if not rows:
        return "<p class='empty'>No data for this section.</p>"
    visible = rows[:max_rows] if max_rows else rows
    columns = columns or list(dict.fromkeys(k for r in visible for k in r.keys()))
    parts = ["<div class='table-wrap'><table><thead><tr>"]
    parts += [f"<th>{esc(c)}</th>" for c in columns]
    parts.append("</tr></thead><tbody>")
    for row in visible:
        parts.append("<tr>")
        for col in columns:
            value = row.get(col, "")
            if col.lower() in {"severity", "status", "state"}:
                parts.append(f"<td>{badge(value) if value else ''}</td>")
            else:
                parts.append(f"<td>{esc(value)}</td>")
        parts.append("</tr>")
    parts.append("</tbody></table></div>")
    if max_rows and len(rows) > max_rows:
        parts.append(f"<p class='small'>Showing {max_rows} of {len(rows)} rows.</p>")
    return "".join(parts)


def section(title: str, body: str, open_: bool = False) -> str:
    opened = " open" if open_ else ""
    return f"<details{opened}><summary>{esc(title)}</summary>{body}</details>"


def build_html_report(report: Dict[str, Any]) -> str:
    health = report.get("health", {})
    tables = report.get("tables", {})
    findings = report.get("findings", [])
    accepted = set(report.get("accepted_findings", []))
    active_findings = [f for f in findings if f.get("Finding ID") not in accepted]
    generated = report.get("generated_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    finding_rows = []
    for f in active_findings:
        finding_rows.append({
            "Severity": f.get("Severity", ""),
            "Category": f.get("Category", ""),
            "Device": f.get("Device", ""),
            "Peer Device": f.get("Peer Device", ""),
            "Problem": f.get("Problem", ""),
            "What this means": f.get("Plain English", ""),
            "Recommended Action": f.get("Recommended Action", ""),
            "Possible Config / Verification": f.get("Configuration Hint", ""),
        })

    device_health_rows = []
    for d in report.get("devices", []):
        name = d.get("name", "UNKNOWN")
        status = "GREEN"
        if name in health.get("red_devices", []):
            status = "RED"
        elif name in health.get("yellow_devices", []):
            status = "YELLOW"
        device_health_rows.append({"Device": name, "Status": status, "Role": d.get("role", ""), "Management IP": d.get("host", ""), "Model": d.get("model", ""), "EOS": d.get("software_version", "")})

    metrics = f"""
    <div class='metric-grid'>
      <div class='metric'><div class='label'>Healthy devices</div><div class='value green'>{health.get('green_count',0)} / {health.get('devices_checked',0)}</div></div>
      <div class='metric'><div class='label'>Attention</div><div class='value yellow'>{health.get('yellow_count',0)}</div></div>
      <div class='metric'><div class='label'>Down / unreachable</div><div class='value red'>{health.get('red_count',0)}</div></div>
      <div class='metric'><div class='label'>eAPI reachable</div><div class='value'>{esc(health.get('eapi_reachable',''))}</div></div>
    </div>
    """

    body = "".join([
        metrics,
        section("Findings first", table(finding_rows), True),
        section("Device health", table(device_health_rows), True),
        section("Device profile summary", table(tables.get("device_profiles", [])), False),
        section("Interfaces", table(tables.get("interfaces", []), ["Device", "Interface", "Status", "VLAN", "Mode", "Speed", "Description"], 500), False),
        section("VLANs", table(tables.get("vlans", []), ["Device", "VLAN", "Name", "Status", "Interfaces"], 500), False),
        section("BGP neighbors", table(tables.get("bgp", []), ["Device", "AFI", "VRF", "Neighbor", "ASN", "State", "Prefixes", "Uptime"], 500), False),
        section("EVPN neighbors", table(tables.get("evpn", []), max_rows=500), False),
        section("LLDP topology data", table([{ "Device": r.get("Device", ""), "Port": r.get("Interface", ""), "Neighbor": r.get("Neighbor", ""), "Port ID": r.get("Neighbor Port", "") } for r in tables.get("lldp", [])], max_rows=500), False),
        section("Command failures", table(tables.get("command_failures", []), max_rows=500), False),
        section("Raw command output preview", table(tables.get("command_outputs", []), max_rows=500), False),
    ])

    return f"""<!doctype html>
<html><head><meta charset='utf-8'><title>FabricOps Report</title>
<style>
body{{margin:0;background:#f6f8fb;color:#111827;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Arial,sans-serif;}}
.page{{max-width:1320px;margin:auto;padding:34px;}}
.hero{{background:#fff;border:1px solid #d9e0ea;border-radius:18px;padding:24px;margin-bottom:18px;box-shadow:0 10px 24px rgba(15,23,42,.06);}}
h1{{margin:0 0 6px 0;font-size:32px;letter-spacing:-.02em;}}
.sub{{color:#667085;font-size:14px;}}
.metric-grid{{display:grid;grid-template-columns:repeat(4,minmax(160px,1fr));gap:14px;margin:16px 0;}}
.metric{{background:#fff;border:1px solid #d9e0ea;border-radius:16px;padding:18px;}}
.label{{font-size:12px;color:#667085;text-transform:uppercase;letter-spacing:.06em;}}
.value{{font-size:28px;font-weight:800;margin-top:8px;}}
.green{{color:#16a34a}} .yellow{{color:#ca8a04}} .red{{color:#dc2626}}
details{{background:#fff;border:1px solid #d9e0ea;border-radius:16px;padding:0;margin:14px 0;box-shadow:0 10px 24px rgba(15,23,42,.04);}}
summary{{cursor:pointer;font-weight:800;padding:16px 18px;border-radius:16px;}}
.table-wrap{{overflow:auto;border-top:1px solid #d9e0ea;}}
table{{width:100%;border-collapse:collapse;font-size:13px;min-width:850px;}}
th{{background:#eef2f7;color:#111827;text-align:left;padding:10px;border-bottom:1px solid #d9e0ea;}}
td{{padding:9px 10px;border-bottom:1px solid #e5e7eb;vertical-align:top;}}
.badge{{display:inline-block;padding:4px 9px;border-radius:999px;font-size:11px;font-weight:800;border:1px solid #d9e0ea;}}
.badge.green{{background:#dcfce7;color:#166534;border-color:#86efac;}}
.badge.yellow{{background:#fef9c3;color:#854d0e;border-color:#fde047;}}
.badge.red{{background:#fee2e2;color:#991b1b;border-color:#fca5a5;}}
.badge.neutral{{background:#f1f5f9;color:#334155;}}
.empty,.small{{color:#667085;padding:0 18px 16px 18px;}}
</style></head>
<body><div class='page'>
<div class='hero'><h1>FabricOps Report</h1><div class='sub'>Profile: {esc(report.get('profile',''))} · Scope: {esc(report.get('scope',''))} · Generated: {esc(generated)}</div></div>
{body}
</div></body></html>"""
