from __future__ import annotations

from datetime import datetime, timezone
from typing import Any


def clean(value: Any, allow_na: bool = False) -> str:
    if value is None:
        return "N/A" if allow_na else ""
    text = str(value).strip()
    if text.lower() in {"n/a", "none", "null", "unknown", "[]", "{}"}:
        return "N/A" if allow_na else ""
    return text


def format_speed(value: Any) -> str:
    if value is None or value == "":
        return ""
    try:
        n = float(value)
    except Exception:
        return clean(value)
    if n <= 0:
        return ""
    units = [(1_000_000_000_000, "T"), (1_000_000_000, "G"), (1_000_000, "M"), (1_000, "K")]
    for factor, suffix in units:
        if n >= factor:
            val = n / factor
            if abs(val - round(val)) < 0.05:
                return f"{int(round(val))}{suffix}"
            return f"{val:.1f}{suffix}"
    return f"{int(n)}bps"


def format_duration(value: Any) -> str:
    if value is None or value == "":
        return ""
    if isinstance(value, str):
        text = value.strip()
        # EOS sometimes already gives strings like 01:23:45 or 2d03h.
        if any(ch.isalpha() for ch in text) or ":" in text:
            return text
        try:
            num = float(text)
        except Exception:
            return text
    else:
        try:
            num = float(value)
        except Exception:
            return clean(value)

    # If this looks like a UNIX timestamp, convert to age.
    if num > 1_000_000_000:
        now = datetime.now(timezone.utc).timestamp()
        seconds = max(0, now - num)
    else:
        seconds = max(0, num)

    return seconds_to_human(seconds)


def seconds_to_human(seconds: float) -> str:
    seconds = int(seconds)
    if seconds < 60:
        return f"{seconds}s"
    minutes = seconds // 60
    if minutes < 60:
        return f"{minutes}m {seconds % 60}s"
    hours = minutes // 60
    if hours < 24:
        return f"{hours}h {minutes % 60}m"
    days = hours // 24
    if days < 30:
        return f"{days}d {hours % 24}h"
    months = days // 30
    if months < 12:
        return f"{months}mo {days % 30}d"
    years = days // 365
    return f"{years}y {days % 365}d"
