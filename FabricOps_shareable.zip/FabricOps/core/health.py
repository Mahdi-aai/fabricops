from __future__ import annotations

import hashlib
import ipaddress
import re
from datetime import datetime
from typing import Any, Dict, List, Tuple

from core.roles import short_name, infer_role


def _s(value: Any) -> str:
    return "" if value is None else str(value).strip()


def _state(value: Any) -> str:
    return _s(value).lower()


def _finding_id(category: str, device: str, obj: str, problem: str, evidence_key: str = "") -> str:
    raw = f"{category}|{short_name(device)}|{obj}|{problem}|{evidence_key[:180]}".encode("utf-8", "ignore")
    return hashlib.sha1(raw).hexdigest()[:14]


def _add(findings: List[Dict[str, Any]], severity: str, category: str, device: str, problem: str,
         action: str, evidence: Any = "", config_hint: str = "", obj: str = "",
         peer_device: str = "", plain: str = "") -> None:
    evidence_text = _s(evidence)
    obj = _s(obj)
    findings.append({
        "Finding ID": _finding_id(category, device, obj, problem, evidence_text),
        "Severity": severity.upper(),
        "Category": category,
        "Device": device,
        "Object": obj,
        "Peer Device": peer_device,
        "Problem": problem,
        "Plain English": plain or _plain(category, device, obj),
        "Evidence": evidence_text,
        "Recommended Action": action,
        "Configuration Hint": config_hint,
        "Created At": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
    })


def _plain(category: str, device: str, obj: str = "") -> str:
    c = category.lower()
    if c == "bgp":
        return f"{device} has a routing neighbor that is not fully connected. Routes may not be exchanged with that peer."
    if c == "evpn":
        return f"{device} has an overlay control-plane neighbor that is not fully connected. VXLAN/EVPN information may not be shared correctly."
    if c == "ospf":
        return f"{device} has an OSPF neighbor that is not fully formed. The two devices may not be sharing routes correctly."
    if c == "mlag":
        return f"{device} has an MLAG condition that needs review. Redundant switching may not be fully healthy."
    if c == "expected link":
        return f"A required physical connection for {device} is missing or down."
    if c == "host link":
        return f"{device} appears disconnected from the fabric."
    if c == "interface":
        return f"{device} has a port reporting errors or drops."
    if c == "eapi":
        return f"FabricOps could not read live data from {device}."
    if c == "cloudvision":
        return f"CloudVision does not show {device} as actively streaming."
    return f"{device} needs attention."


def _is_bgp_up(value: Any) -> bool:
    st = _state(value)
    return st.isdigit() or "established" in st or st == "estab"


def _is_ospf_up(value: Any) -> bool:
    return "full" in _state(value)


def _is_interface_up(value: Any) -> bool:
    st = _state(value)
    return st in {"connected", "up", "active"} or st.startswith("up")


def _interface_ip(address: Any) -> str:
    text = _s(address)
    if not text:
        return ""
    token = text.split()[0]
    if "/" in token:
        try:
            return str(ipaddress.ip_interface(token).ip)
        except Exception:
            return token.split("/")[0]
    return token if re.match(r"^\d+\.\d+\.\d+\.\d+$", token) else ""


def _ip_maps(tables: Dict[str, List[Dict[str, Any]]]) -> Tuple[Dict[str, str], Dict[str, List[str]]]:
    ip_to_device: Dict[str, str] = {}
    device_to_ips: Dict[str, List[str]] = {}
    for row in tables.get("ip_interfaces", []):
        dev = short_name(row.get("Device"))
        ip = _interface_ip(row.get("Address"))
        if dev and ip:
            ip_to_device[ip] = dev
            device_to_ips.setdefault(dev, []).append(ip)
    return ip_to_device, device_to_ips


def _bgp_context(row: Dict[str, Any], tables: Dict[str, List[Dict[str, Any]]]) -> Tuple[str, str, str]:
    device = short_name(row.get("Device"))
    neighbor = _s(row.get("Neighbor"))
    remote_as = _s(row.get("ASN"))
    afi = _s(row.get("AFI")) or "IPv4"
    ip_to_device, device_to_ips = _ip_maps(tables)
    peer_device = ip_to_device.get(neighbor, "")
    if peer_device:
        local_ips = set(device_to_ips.get(device, []))
        reciprocal = [r for r in tables.get("bgp", []) if short_name(r.get("Device")) == peer_device and _s(r.get("Neighbor")) in local_ips]
        if reciprocal:
            peer_state = ", ".join(f"{r.get('Neighbor')}={r.get('State')}" for r in reciprocal)
            evidence = f"Peer IP {neighbor} maps to {peer_device}. Reciprocal BGP evidence on {peer_device}: {peer_state}."
        else:
            evidence = f"Peer IP {neighbor} maps to {peer_device}, but FabricOps did not find a reciprocal BGP neighbor pointing back to {device}."
    else:
        evidence = f"FabricOps could not map neighbor IP {neighbor} to a collected device interface. It may be unused, missing, or configured with a different address."

    if afi.lower() == "evpn":
        hint = (
            "Possible EOS configuration to verify:\n"
            "router bgp <local-as>\n"
            f"   neighbor {neighbor} remote-as {remote_as or '<remote-as>'}\n"
            f"   neighbor {neighbor} update-source Loopback0\n"
            f"   neighbor {neighbor} ebgp-multihop 3\n"
            "   address-family evpn\n"
            f"      neighbor {neighbor} activate\n"
            f"      neighbor {neighbor} send-community extended\n"
            "! Also verify underlay reachability to the peer loopback."
        )
    else:
        hint = (
            "Possible EOS configuration to verify:\n"
            "router bgp <local-as>\n"
            f"   neighbor {neighbor} remote-as {remote_as or '<remote-as>'}\n"
            f"   neighbor {neighbor} description <peer-device>\n"
            "   address-family ipv4\n"
            f"      neighbor {neighbor} activate\n"
            "! Verify interface IPs, remote ASN, and reciprocal neighbor statement on the peer."
        )
    return peer_device, evidence, hint


def _edge_tuple(a: str, b: str) -> tuple:
    return tuple(sorted([short_name(a), short_name(b)]))


def _lldp_edges(tables: Dict[str, List[Dict[str, Any]]]) -> Dict[tuple, List[Dict[str, Any]]]:
    edges: Dict[tuple, List[Dict[str, Any]]] = {}
    for r in tables.get("lldp", []):
        a = short_name(r.get("Device"))
        b = short_name(r.get("Neighbor"))
        if a and b and a != b:
            edges.setdefault(_edge_tuple(a, b), []).append(r)
    return edges


def _interface_lookup(tables: Dict[str, List[Dict[str, Any]]]) -> Dict[tuple, Dict[str, Any]]:
    lookup: Dict[tuple, Dict[str, Any]] = {}
    for r in tables.get("interfaces", []):
        dev = short_name(r.get("Device"))
        intf = _s(r.get("Interface")).lower()
        if dev and intf:
            lookup[(dev, intf)] = r
    return lookup


def _find_host_access_interface(host: str, tables: Dict[str, List[Dict[str, Any]]]) -> Dict[str, Any]:
    h = short_name(host)
    digits = "".join(ch for ch in h if ch.isdigit())
    for row in tables.get("interfaces", []):
        dev = short_name(row.get("Device"))
        if dev == h:
            continue
        desc = _s(row.get("Description")).lower().replace("-", "_")
        if h and h in desc:
            return row
        if digits and (f"host{digits}" in desc or f"host_{digits}" in desc or f"h{digits}" in desc):
            return row
    return {}


def _exception_matches(finding: Dict[str, Any], exceptions: List[Dict[str, Any]]) -> bool:
    fid = _s(finding.get("Finding ID"))
    dev = short_name(finding.get("Device"))
    cat = _s(finding.get("Category")).lower()
    obj = _s(finding.get("Object") or finding.get("Problem"))
    for ex in exceptions or []:
        if _s(ex.get("id")) == fid:
            return True
        if short_name(ex.get("device")) == dev and _s(ex.get("feature")).lower() == cat:
            ex_obj = _s(ex.get("object"))
            if not ex_obj or ex_obj in obj or ex_obj in _s(finding.get("Problem")) or ex_obj in _s(finding.get("Evidence")):
                return True
    return False


def apply_expected_exceptions(findings: List[Dict[str, Any]], exceptions: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    result = []
    for f in findings:
        row = dict(f)
        row["Expected Exception"] = _exception_matches(row, exceptions)
        result.append(row)
    return result


def _expected_links(expected_topology: Dict[str, Any]) -> List[Dict[str, Any]]:
    if not isinstance(expected_topology, dict):
        return []
    links = expected_topology.get("expected_links") or []
    return [x for x in links if isinstance(x, dict)]


def _missing_expected_link_findings(findings: List[Dict[str, Any]], tables: Dict[str, List[Dict[str, Any]]], expected_topology: Dict[str, Any]) -> None:
    edges = _lldp_edges(tables)
    if_lookup = _interface_lookup(tables)
    for link in _expected_links(expected_topology):
        if link.get("required") is False:
            continue
        a = short_name(link.get("local_device"))
        b = short_name(link.get("remote_device"))
        ai = _s(link.get("local_interface"))
        bi = _s(link.get("remote_interface"))
        ltype = _s(link.get("link_type") or "link")
        if not a or not b:
            continue
        key = _edge_tuple(a, b)
        actual = edges.get(key, [])
        local_row = if_lookup.get((a, ai.lower()), {}) if ai else {}
        remote_row = if_lookup.get((b, bi.lower()), {}) if bi else {}
        local_down = local_row and not _is_interface_up(local_row.get("Status"))
        remote_down = remote_row and not _is_interface_up(remote_row.get("Status"))
        missing = not actual
        wrong_port = False
        if actual and (ai or bi):
            # If both ports are known, require at least one LLDP row to match local side.
            texts = [f"{_s(r.get('Interface')).lower()}|{_s(r.get('Neighbor Port')).lower()}" for r in actual]
            if ai and not any(ai.lower() in t for t in texts):
                wrong_port = True
        if missing or local_down or remote_down or wrong_port:
            severity = "RED" if ltype in {"access", "host", "mlag_peer"} or "host" in {a, b} else "YELLOW"
            dev = a if "host" not in a else a
            object_text = f"{a} {ai} ↔ {b} {bi}".strip()
            status_parts = []
            if missing:
                status_parts.append("LLDP edge is missing")
            if local_down:
                status_parts.append(f"{a} {ai} is {local_row.get('Status')}")
            if remote_down:
                status_parts.append(f"{b} {bi} is {remote_row.get('Status')}")
            if wrong_port:
                status_parts.append("LLDP edge was found but not on the expected port")
            action = f"Check the required {ltype} connection between {a} and {b}. Verify cable, no shutdown, interface mode, and the expected neighbor/port."
            hint = "Possible EOS configuration to verify:\n"
            if ai:
                hint += f"interface {ai}\n   no shutdown\n"
            if ltype == "access":
                hint += "   switchport mode access\n   switchport access vlan <expected-vlan>\n"
            elif ltype in {"trunk", "mlag_peer"}:
                hint += "   switchport mode trunk\n"
            _add(
                findings, severity, "Expected Link", dev,
                f"Expected link is not healthy: {object_text}",
                action,
                evidence={"expected": link, "status": "; ".join(status_parts), "actual_lldp_rows": actual},
                config_hint=hint,
                obj=object_text,
                peer_device=b,
                plain=f"The required connection between {a} and {b} is missing or not healthy.",
            )


def analyze_health(devices: List[Dict[str, Any]], device_results: List[Dict[str, Any]], tables: Dict[str, List[Dict[str, Any]]], live_mode: bool,
                   expected_topology: Dict[str, Any] | None = None, expected_exceptions: List[Dict[str, Any]] | None = None,
                   role_overrides: Dict[str, str] | None = None, use_expected_topology: bool = True) -> Tuple[Dict[str, Any], List[Dict[str, Any]], List[Dict[str, Any]]]:
    expected_topology = expected_topology or {"devices": {}, "expected_links": []}
    expected_exceptions = expected_exceptions or []
    role_overrides = role_overrides or {}
    findings: List[Dict[str, Any]] = []

    device_by_name = {short_name(d.get("name")): d for d in devices}
    role_profiles = {short_name(d.get("name")): infer_role(d, tables, role_overrides, expected_topology) for d in devices}

    for d in devices:
        name = _s(d.get("name")) or "UNKNOWN"
        if not d.get("cloudvision_active"):
            _add(findings, "RED", "CloudVision", name, "Device is not actively streaming to CloudVision.",
                 f"Check CloudVision onboarding, TerminAttr, management reachability, and device telemetry for {name}.",
                 d.get("streaming_status", "UNKNOWN"),
                 "show daemon TerminAttr\nshow management api http-commands\n! Verify management VRF reachability to CloudVision.", obj="streaming")

    if live_mode:
        for result in device_results:
            name = _s((result.get("device") or {}).get("name")) or "UNKNOWN"
            if not result.get("skipped") and not result.get("reachable"):
                _add(findings, "RED", "eAPI", name, "EOS eAPI collection failed or device was not reachable.",
                     f"On {name}, verify management IP, HTTPS eAPI on port 443, credentials, SSL verification setting, and management VRF.",
                     result.get("error", ""),
                     "management api http-commands\n   protocol https port 443\n   no shutdown\n   vrf management\n      no shutdown", obj="eapi")

    for row in tables.get("bgp", []):
        device = _s(row.get("Device"))
        role = role_profiles.get(short_name(device), {})
        if not role.get("has_l3", False):
            continue
        if not _is_bgp_up(row.get("State")):
            neighbor = _s(row.get("Neighbor"))
            peer_device, peer_sentence, hint = _bgp_context(row, tables)
            _add(findings, "YELLOW", "BGP", device, f"BGP neighbor {neighbor} is {row.get('State')} instead of Established.",
                 f"On {device}, check neighbor {neighbor}: remote ASN {row.get('ASN','')}, peer reachability, source interface, and reciprocal configuration. {peer_sentence}",
                 row, hint, obj=neighbor, peer_device=peer_device,
                 plain=f"{device} has a BGP connection to {neighbor} that is not up.")

    for row in tables.get("evpn", []):
        device = _s(row.get("Device"))
        if not _is_bgp_up(row.get("State")):
            neighbor = _s(row.get("Neighbor"))
            peer_device, peer_sentence, hint = _bgp_context(row, tables)
            _add(findings, "YELLOW", "EVPN", device, f"EVPN neighbor {neighbor} is {row.get('State')} instead of Established.",
                 f"On {device}, verify EVPN peer {neighbor}, update-source Loopback0, route-reflector relationship, and underlay reachability. {peer_sentence}",
                 row, hint, obj=neighbor, peer_device=peer_device,
                 plain=f"{device} has an EVPN overlay connection that is not up.")

    for row in tables.get("ospf", []):
        device = _s(row.get("Device"))
        role = role_profiles.get(short_name(device), {})
        if not role.get("has_l3", False):
            continue
        if not _is_ospf_up(row.get("State")):
            iface = _s(row.get("Interface"))
            neighbor = _s(row.get("Neighbor"))
            _add(findings, "YELLOW", "OSPF", device, f"OSPF neighbor {neighbor} is not Full.",
                 f"On {device}, verify OSPF area, MTU, timers, passive-interface, and interface {iface}.",
                 row, f"show ip ospf interface {iface}\n! Verify matching area, MTU, timers, and network type on both ends.", obj=neighbor,
                 plain=f"{device} has an OSPF connection that is not fully formed.")

    for row in tables.get("mlag", []):
        device = _s(row.get("Device"))
        text = str(row).lower()
        if any(w in text for w in ["inactive", "down", "inconsistent", "negotiating", "disabled", "error", "failed"]):
            _add(findings, "YELLOW", "MLAG", device, "MLAG state appears unhealthy.",
                 f"On {device}, check MLAG peer-link, VLAN4094, local-interface, peer address, and config-sanity output.",
                 row, "show mlag\nshow mlag config-sanity\nshow interfaces Port-Channel1\n! Verify peer-link, VLAN4094, and local-interface on both MLAG peers.", obj="mlag",
                 plain=f"{device} has an MLAG redundancy condition that needs review.")

    for row in tables.get("interface_errors", []):
        device = _s(row.get("Device"))
        interface = _s(row.get("Interface"))
        _add(findings, "YELLOW", "Interface", device, f"Interface {interface} has non-zero error or discard counters.",
             f"Inspect {device} {interface}. Check cable, optic, speed/duplex, peer port, and recent logs.",
             row, f"show interfaces {interface}\nshow logging last 100 | include {interface}\n! Verify cable/optic and connected peer port.", obj=interface,
             plain=f"{device} has a port that is reporting errors or drops.")

    for row in tables.get("vxlan", []):
        if _s(row.get("Status")).upper() == "DOWN":
            device = _s(row.get("Device"))
            _add(findings, "YELLOW", "VXLAN", device, "VXLAN interface or VTEP evidence indicates DOWN.",
                 f"On {device}, verify VTEP loopback reachability, underlay routes, EVPN peers, VXLAN interface, VNIs, and VLAN/VRF mappings.",
                 row, "interface Vxlan1\n   vxlan source-interface Loopback1\n   vxlan vlan <vlan> vni <vni>\n   vxlan vrf <vrf> vni <l3-vni>", obj="vxlan",
                 plain=f"{device} has VXLAN evidence that may not be working correctly.")

    if use_expected_topology and expected_topology:
        _missing_expected_link_findings(findings, tables, expected_topology)

    # Host visibility check even without expected topology. This is intentionally strict.
    lldp_nodes = set()
    for row in tables.get("lldp", []):
        lldp_nodes.add(short_name(row.get("Device")))
        lldp_nodes.add(short_name(row.get("Neighbor")))
    for d in devices:
        name = _s(d.get("name")) or "UNKNOWN"
        if role_profiles.get(short_name(name), {}).get("tier") != "host":
            continue
        if short_name(name) not in lldp_nodes:
            ref = _find_host_access_interface(name, tables)
            if ref:
                sw = _s(ref.get("Device"))
                intf = _s(ref.get("Interface"))
                status = _s(ref.get("Status"))
                action = f"Check the cable and interface between {sw} {intf} and {name}. The likely switch port status is '{status or 'unknown'}'."
                hint = f"interface {intf}\n   description {name}_ACCESS\n   no shutdown"
                evidence = {"likely_switch": sw, "interface": intf, "status": status, "description": ref.get("Description", "")}
            else:
                action = f"Check the host link for {name}. FabricOps cannot see it in LLDP. If LLDP is disabled on hosts, create an expected topology baseline."
                hint = "show lldp neighbors\nshow interfaces status"
                evidence = "Host was not seen in any LLDP edge."
            # Do not duplicate if expected link already created a finding for this same host.
            if not any(short_name(f.get("Device")) == short_name(name) and f.get("Category") in {"Expected Link", "Host Link"} for f in findings):
                _add(findings, "RED", "Host Link", name, f"No active LLDP connection was detected for {name}.",
                     action, evidence, hint, obj="fabric-link",
                     plain=f"{name} appears disconnected from the fabric.")

    findings = apply_expected_exceptions(findings, expected_exceptions)
    health = recompute_device_health(devices, findings, accepted_ids=set(), include_exceptions=True)
    health.update({
        "live_mode": live_mode,
        "cloudvision_active": sum(1 for d in devices if d.get("cloudvision_active")),
        "eapi_reachable": sum(1 for r in device_results if r.get("reachable")) if live_mode else "Not tested",
        "findings_count": len(findings),
        "expected_exception_count": sum(1 for f in findings if f.get("Expected Exception")),
    })
    recommendations = [{k: f.get(k, "") for k in ["Severity", "Device", "Category", "Object", "Problem", "Recommended Action", "Configuration Hint"]} for f in findings]
    return health, findings, recommendations


def recompute_device_health(devices: List[Dict[str, Any]], findings: List[Dict[str, Any]], accepted_ids: set[str] | None = None,
                            include_exceptions: bool = True) -> Dict[str, Any]:
    accepted_ids = accepted_ids or set()
    device_names = [_s(d.get("name")) for d in devices if _s(d.get("name"))]
    active: List[Dict[str, Any]] = []
    for f in findings:
        if f.get("Finding ID") in accepted_ids:
            continue
        if include_exceptions and f.get("Expected Exception"):
            continue
        active.append(f)
    red_devices = sorted({f["Device"] for f in active if _s(f.get("Severity")).upper() == "RED"})
    yellow_devices = sorted({f["Device"] for f in active if _s(f.get("Severity")).upper() == "YELLOW" and f["Device"] not in red_devices})
    green_devices = sorted([d for d in device_names if d not in red_devices and d not in yellow_devices])
    status_by_device = {d: "GREEN" for d in device_names}
    for d in yellow_devices:
        status_by_device[d] = "YELLOW"
    for d in red_devices:
        status_by_device[d] = "RED"
    return {
        "status": "RED" if red_devices else ("YELLOW" if yellow_devices else "GREEN"),
        "devices_checked": len(device_names),
        "red_devices": red_devices,
        "yellow_devices": yellow_devices,
        "green_devices": green_devices,
        "red_count": len(red_devices),
        "yellow_count": len(yellow_devices),
        "green_count": len(green_devices),
        "status_by_device": status_by_device,
        "active_findings": active,
        "accepted_count": len([f for f in findings if f.get("Finding ID") in accepted_ids]),
    }


def exception_from_finding(finding: Dict[str, Any], reason: str = "Expected in this lab.") -> Dict[str, Any]:
    return {
        "id": finding.get("Finding ID"),
        "device": short_name(finding.get("Device")),
        "feature": finding.get("Category"),
        "object": finding.get("Object") or finding.get("Problem"),
        "reason": reason,
        "created_at": datetime.now().strftime("%Y-%m-%d"),
        "expires_at": None,
    }
