from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict

DATA_DIR = Path("fabricops_data")


def ensure_data_dir() -> Path:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    return DATA_DIR


def load_json(name: str, default: Any) -> Any:
    ensure_data_dir()
    path = DATA_DIR / name
    if not path.exists():
        return default
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return default


def save_json(name: str, data: Any) -> Path:
    ensure_data_dir()
    path = DATA_DIR / name
    path.write_text(json.dumps(data, indent=2, sort_keys=True), encoding="utf-8")
    return path


def load_expected_topology() -> Dict[str, Any]:
    ensure_data_dir()
    json_path = DATA_DIR / "expected_topology.json"
    yaml_path = DATA_DIR / "expected_topology.yaml"
    if json_path.exists():
        return load_json("expected_topology.json", {"devices": {}, "expected_links": []})
    if yaml_path.exists():
        try:
            import yaml  # type: ignore
            data = yaml.safe_load(yaml_path.read_text(encoding="utf-8")) or {}
            if isinstance(data, dict):
                data.setdefault("devices", {})
                data.setdefault("expected_links", [])
                return data
        except Exception:
            pass
    return {"devices": {}, "expected_links": []}


def save_expected_topology(data: Dict[str, Any]) -> Path:
    data = data or {"devices": {}, "expected_links": []}
    data.setdefault("devices", {})
    data.setdefault("expected_links", [])
    return save_json("expected_topology.json", data)


def load_role_overrides() -> Dict[str, str]:
    data = load_json("role_overrides.json", {})
    return data if isinstance(data, dict) else {}


def save_role_overrides(data: Dict[str, str]) -> Path:
    clean = {str(k): str(v) for k, v in (data or {}).items() if v and v != "Auto-detect"}
    return save_json("role_overrides.json", clean)


def load_expected_exceptions() -> list[dict]:
    data = load_json("expected_exceptions.json", [])
    return data if isinstance(data, list) else []


def save_expected_exceptions(data: list[dict]) -> Path:
    return save_json("expected_exceptions.json", data or [])


def save_last_validation(data: Dict[str, Any]) -> Path:
    return save_json("last_validation.json", data)


def load_last_validation() -> Dict[str, Any]:
    data = load_json("last_validation.json", {})
    return data if isinstance(data, dict) else {}
