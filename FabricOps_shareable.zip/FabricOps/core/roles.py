from __future__ import annotations

import re
from typing import Any, Dict, List, Tuple

ROLE_ORDER = {"router": 0, "spine": 1, "leaf": 2, "memleaf": 3, "host": 4, "unknown": 9, "other": 9}
ROLE_GROUP_LABELS = {"router": "Routers", "spine": "Spines", "leaf": "Leafs", "memleaf": "Memleafs", "host": "Hosts", "unknown": "Other Devices", "other": "Other Devices"}

ROLE_OPTIONS = [
    "Auto-detect",
    "Router",
    "Layer 3 Spine",
    "Layer 2 / Layer 3 Spine",
    "Layer 3 Leaf",
    "Layer 2 Leaf",
    "Layer 3 Leaf with Access",
    "Access/Memleaf",
    "Host",
    "Inventory Only",
]


def short_name(value: Any) -> str:
    return str(value or "").strip().split()[0].split(".")[0].lower()


def natural_key(value: Any) -> tuple:
    text = str(value or "").lower()
    parts = re.split(r"(\d+)", text)
    return tuple(int(p) if p.isdigit() else p for p in parts)


def device_group(name: Any, role: Any = "") -> str:
    n = short_name(name)
    r = str(role or "").lower()
    if "router" in n or "router" in r:
        return "router"
    if "spine" in n or "spine" in r:
        return "spine"
    if "memleaf" in n or "memleaf" in r:
        return "memleaf"
    if n.startswith("leaf") or "leaf" in r:
        return "leaf"
    if "host" in n or "host" in r:
        return "host"
    return "unknown"


def device_sort_key(device_or_name: Any) -> tuple:
    if isinstance(device_or_name, dict):
        name = device_or_name.get("name", "")
        role = device_or_name.get("role", "")
    else:
        name, role = str(device_or_name or ""), ""
    group = device_group(name, role)
    return (ROLE_ORDER.get(group, 9), natural_key(name))


def order_devices(devices: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    return sorted(devices, key=device_sort_key)


def _rows_for(tables: Dict[str, List[Dict[str, Any]]], key: str, device: str) -> List[Dict[str, Any]]:
    d = short_name(device)
    return [r for r in tables.get(key, []) if short_name(r.get("Device")) == d]


def expected_role(expected_topology: Dict[str, Any], device: str) -> str:
    devices = expected_topology.get("devices", {}) if isinstance(expected_topology, dict) else {}
    d = devices.get(short_name(device)) or devices.get(str(device)) or {}
    if isinstance(d, str):
        return d
    if isinstance(d, dict):
        return str(d.get("role") or "")
    return ""


def infer_role(device: Dict[str, Any], tables: Dict[str, List[Dict[str, Any]]], role_overrides: Dict[str, str] | None = None, expected_topology: Dict[str, Any] | None = None) -> Dict[str, Any]:
    """Return a role profile. Manual override and expected topology are stronger than auto detection."""
    role_overrides = role_overrides or {}
    expected_topology = expected_topology or {}
    name = str(device.get("name") or "")
    short = short_name(name)

    override = role_overrides.get(short) or role_overrides.get(name)
    if override and override != "Auto-detect":
        label = override
        source = "Manual override"
    else:
        er = expected_role(expected_topology, short)
        if er:
            label = er
            source = "Expected topology"
        else:
            label = _auto_role(device, tables)
            source = "Auto-detected"

    label_l = label.lower()
    tier = device_group(name, label)
    has_l2 = any(x in label_l for x in ["layer 2", "access", "memleaf"]) or label_l == "host"
    has_l3 = any(x in label_l for x in ["router", "layer 3"])
    has_access = any(x in label_l for x in ["access", "memleaf", "host"])
    has_overlay = any(x in label_l for x in ["overlay", "vxlan", "evpn"])
    mlag_expected = "memleaf" in label_l or "layer 2 / layer 3 spine" in label_l or "layer 2 leaf" in label_l

    if label_l == "host":
        has_l2 = False
        has_l3 = False
        has_access = True
        mlag_expected = False

    return {
        "device": name,
        "short": short,
        "role": label,
        "tier": tier,
        "source": source,
        "has_l2": has_l2,
        "has_l3": has_l3,
        "has_access": has_access,
        "has_overlay": has_overlay,
        "mlag_expected": mlag_expected,
        "requirements": role_requirements(label),
    }


def _auto_role(device: Dict[str, Any], tables: Dict[str, List[Dict[str, Any]]]) -> str:
    name = str(device.get("name") or "")
    short = short_name(name)
    group = device_group(name, device.get("role"))
    interfaces = _rows_for(tables, "interfaces", short)
    vlans = [r for r in _rows_for(tables, "vlans", short) if str(r.get("VLAN", "")) not in {"", "1", "default"}]
    bgp = _rows_for(tables, "bgp", short)
    ospf = _rows_for(tables, "ospf", short)
    mlag = _rows_for(tables, "mlag", short)
    vxlan = _rows_for(tables, "vxlan", short)
    evpn = _rows_for(tables, "evpn", short)
    l3_intfs = [r for r in interfaces if str(r.get("Mode", "")).lower() == "routed"]
    access = [r for r in interfaces if r.get("VLAN") and not str(r.get("Interface", "")).lower().startswith(("port-channel", "management"))]
    trunks = [r for r in interfaces if "trunk" in str(r.get("Mode", "")).lower()]

    has_l2 = bool(vlans or trunks or access or mlag)
    has_l3 = bool(l3_intfs or bgp or ospf)
    has_overlay = bool(vxlan or evpn)

    if group == "router":
        return "Router"
    if group == "host":
        return "Host"
    if group == "memleaf":
        return "Access/Memleaf"
    if group == "spine":
        if has_l2 and has_l3:
            return "Layer 2 / Layer 3 Spine"
        return "Layer 3 Spine" if has_l3 or not has_l2 else "Layer 2 / Layer 3 Spine"
    if group == "leaf":
        if has_l3 and access:
            return "Layer 3 Leaf with Access"
        if has_l3:
            return "Layer 3 Leaf"
        if has_l2:
            return "Layer 2 Leaf"
    if has_overlay:
        return "Layer 2 / Layer 3 / Overlay"
    if has_l3 and has_l2:
        return "Layer 2 / Layer 3"
    if has_l3:
        return "Layer 3"
    if has_l2:
        return "Layer 2"
    return "Inventory Only"


def role_requirements(role: str) -> List[Dict[str, str]]:
    r = str(role or "").lower()
    def row(area: str, status: str, detail: str) -> Dict[str, str]:
        return {"Area": area, "Expectation": status, "Plain English": detail}
    if "router" in r:
        return [
            row("Layer 3 / Routing", "Required", "Routers are expected to use routed links and routing neighbors when configured."),
            row("VLANs / Access", "Not required", "Routers should not be marked unhealthy just because they do not have access VLANs."),
            row("MLAG", "Not required", "Layer 3 routers do not need MLAG unless you explicitly configure it."),
        ]
    if "layer 3 spine" in r and "layer 2" not in r:
        return [
            row("Layer 3 / Routing", "Required", "This spine is expected to use routed uplinks, loopbacks, and routing protocols when configured."),
            row("Layer 2 / VLANs", "Not required", "A pure Layer 3 spine does not need access VLANs or trunks."),
            row("MLAG", "Not required", "A pure Layer 3 spine should not be treated as an MLAG switch."),
        ]
    if "layer 2 / layer 3 spine" in r:
        return [
            row("Layer 2", "Required if configured", "This spine may carry VLANs, trunks, SVIs, or MLAG if configured."),
            row("Layer 3", "Required if configured", "This spine may also participate in routed links and routing protocols."),
            row("MLAG", "Required if configured", "MLAG is expected only when MLAG evidence or expected topology says it is required."),
        ]
    if "memleaf" in r or "access" in r:
        return [
            row("Access ports", "Required", "This device is expected to connect endpoints or downstream hosts."),
            row("Layer 2 / VLANs", "Required", "Access/memleaf devices are expected to carry VLANs and trunks."),
            row("Layer 3 / Routing", "Not required", "This device should not be marked unhealthy for missing BGP or OSPF unless routing is configured."),
        ]
    if "host" in r:
        return [
            row("Fabric connection", "Required", "A host should have at least one live connection to the fabric."),
            row("Routing / MLAG", "Not required", "Hosts are not expected to run MLAG, BGP, OSPF, or VXLAN validation."),
        ]
    if "layer 3 leaf" in r:
        return [
            row("Layer 3", "Required", "This leaf is expected to have routed links or routing protocol state."),
            row("Access", "Required if host-facing", "If it connects a host, the access interface should be up and in the expected VLAN."),
            row("Overlay", "Required if configured", "VXLAN/EVPN is checked only when collected evidence shows an overlay role."),
        ]
    if "layer 2 leaf" in r:
        return [
            row("Layer 2", "Required", "This leaf is expected to carry VLANs, access ports, or trunks."),
            row("Layer 3", "Not required", "Layer 2 leafs are not marked unhealthy for missing BGP/OSPF."),
        ]
    return [row("Validation", "Auto", "FabricOps will validate the features that are discovered or listed in expected topology.")]
