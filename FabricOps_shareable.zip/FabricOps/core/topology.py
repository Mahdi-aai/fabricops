from __future__ import annotations

import html
import re
from typing import Any, Dict, List, Tuple

from core.roles import short_name, device_group, natural_key, order_devices


def esc(v: Any) -> str:
    return html.escape("" if v is None else str(v))


def edge_key(a: str, b: str) -> tuple:
    return tuple(sorted([short_name(a), short_name(b)]))


def lldp_edges(tables: Dict[str, List[Dict[str, Any]]]) -> Dict[tuple, List[Dict[str, Any]]]:
    edges: Dict[tuple, List[Dict[str, Any]]] = {}
    for r in tables.get("lldp", []):
        a, b = short_name(r.get("Device")), short_name(r.get("Neighbor"))
        if a and b and a != b:
            edges.setdefault(edge_key(a, b), []).append(r)
    return edges


def infer_link_type(a: str, b: str, rows: List[Dict[str, Any]], tables: Dict[str, List[Dict[str, Any]]], expected_topology: Dict[str, Any] | None = None) -> str:
    expected_topology = expected_topology or {}
    for link in expected_topology.get("expected_links", []) or []:
        if edge_key(link.get("local_device"), link.get("remote_device")) == edge_key(a, b):
            lt = str(link.get("link_type") or "").lower()
            if lt:
                return lt
    # Strict MLAG: actual MLAG evidence only, not just two cables.
    mlag_devices = {short_name(r.get("Device")) for r in tables.get("mlag", []) if short_name(r.get("Device"))}
    text = " ".join(str(x) for r in rows for x in [r.get("Interface", ""), r.get("Neighbor Port", "")]).lower()
    desc_text = " ".join(str(r.get("Description", "")) for r in tables.get("interfaces", []) if short_name(r.get("Device")) in {short_name(a), short_name(b)}).lower()
    if short_name(a) in mlag_devices and short_name(b) in mlag_devices and ("mlag" in desc_text or "port-channel" in text or re.search(r"\bpo\d+\b", text)):
        return "mlag_peer"
    # Derive from interface mode when available.
    int_lookup = {(short_name(r.get("Device")), str(r.get("Interface", "")).lower()): r for r in tables.get("interfaces", [])}
    modes = []
    for r in rows:
        src = short_name(r.get("Device")); src_intf = str(r.get("Interface", "")).lower()
        dst = short_name(r.get("Neighbor")); dst_intf = str(r.get("Neighbor Port", "")).lower()
        for row in [int_lookup.get((src, src_intf)), int_lookup.get((dst, dst_intf))]:
            if row:
                modes.append(str(row.get("Mode", "")).lower())
    if any("routed" in m for m in modes):
        return "routed_p2p"
    if any("trunk" in m for m in modes):
        return "trunk"
    if any("access" in m or "bridged" in m for m in modes):
        return "access"
    if len(rows) > 1:
        return "parallel"
    return "link"


def build_expected_from_lldp(devices: List[Dict[str, Any]], tables: Dict[str, List[Dict[str, Any]]], role_profiles: Dict[str, Dict[str, Any]] | None = None) -> Dict[str, Any]:
    role_profiles = role_profiles or {}
    devs: Dict[str, Dict[str, Any]] = {}
    for d in devices:
        s = short_name(d.get("name"))
        if not s:
            continue
        prof = role_profiles.get(s, {})
        devs[s] = {"role": prof.get("role") or d.get("role") or "Auto-detect", "tier": prof.get("tier") or device_group(s, d.get("role"))}
    edges = lldp_edges(tables)
    links = []
    for (a, b), rows in sorted(edges.items(), key=lambda item: (natural_key(item[0][0]), natural_key(item[0][1]))):
        ltype = infer_link_type(a, b, rows, tables, {})
        # Use the first row as representative. Store both ends when available.
        first = rows[0]
        local_device = short_name(first.get("Device"))
        remote_device = short_name(first.get("Neighbor"))
        links.append({
            "local_device": local_device,
            "local_interface": str(first.get("Interface") or ""),
            "remote_device": remote_device,
            "remote_interface": str(first.get("Neighbor Port") or ""),
            "link_type": ltype,
            "required": True,
        })
    return {"devices": devs, "expected_links": links}


def _position_nodes(devices: List[Dict[str, Any]], edges: Dict[tuple, List[Dict[str, Any]]], expected_topology: Dict[str, Any] | None = None) -> Dict[str, Tuple[int, int]]:
    width = 2000
    y_by_group = {"router": 80, "spine": 255, "leaf": 455, "memleaf": 650, "host": 835, "unknown": 1010}
    nodes_by_group: Dict[str, List[str]] = {g: [] for g in y_by_group}
    device_map = {short_name(d.get("name")): d for d in devices if short_name(d.get("name"))}
    for name, d in device_map.items():
        group = device_group(name, d.get("role"))
        nodes_by_group.setdefault(group, []).append(name)
    for g in nodes_by_group:
        nodes_by_group[g].sort(key=natural_key)

    pos: Dict[str, Tuple[int, int]] = {}
    def spread(group: str, left: int, right: int) -> None:
        nodes = nodes_by_group.get(group, [])
        if not nodes:
            return
        y = y_by_group.get(group, 1000)
        if len(nodes) == 1:
            xs = [(left + right) // 2]
        else:
            step = (right - left) / (len(nodes) - 1)
            xs = [int(left + i * step) for i in range(len(nodes))]
        for n, x in zip(nodes, xs):
            pos[n] = (x, y)

    routers = nodes_by_group.get("router", [])
    if len(routers) == 2:
        pos[routers[0]] = (720, y_by_group["router"])
        pos[routers[1]] = (1280, y_by_group["router"])
    else:
        spread("router", 660, 1340)

    # Wider spacing for spines. This prevents leafs from overlapping with spine groups.
    spines = nodes_by_group.get("spine", [])
    if len(spines) == 4:
        for n, x in zip(spines, [360, 760, 1240, 1640]):
            pos[n] = (x, y_by_group["spine"])
    else:
        spread("spine", 260, 1740)

    # Leaf layout: known lab-friendly placement, with fallback spread.
    leafs = nodes_by_group.get("leaf", [])
    preferred_leaf_x = {"leaf1": 250, "leaf2": 560, "leaf3": 900, "leaf4": 1210, "leaf5": 1540, "leaf6": 1710, "leaf7": 1870}
    fallback_positions = []
    if leafs:
        if len(leafs) == 1:
            fallback_positions = [1000]
        else:
            left, right = 240, 1760
            step = (right - left) / max(1, len(leafs)-1)
            fallback_positions = [int(left + i*step) for i in range(len(leafs))]
    for i, n in enumerate(leafs):
        pos[n] = (preferred_leaf_x.get(n, fallback_positions[i]), y_by_group["leaf"])

    mems = nodes_by_group.get("memleaf", [])
    preferred_mem_x = {"memleaf1": 900, "memleaf2": 1210}
    for i, n in enumerate(mems):
        pos[n] = (preferred_mem_x.get(n, 820 + i * 300), y_by_group["memleaf"])

    hosts = nodes_by_group.get("host", [])
    preferred_host_x = {"host1": 250, "host2": 560, "host3": 900, "host4": 1210, "host5": 1540, "host6": 1710, "host7": 1870}
    for i, n in enumerate(hosts):
        # center under LLDP parent if available, otherwise known position or spread.
        parent_xs = []
        for k in edges:
            if n in k:
                other = k[0] if k[1] == n else k[1]
                if other in pos and pos[other][1] < y_by_group["host"]:
                    parent_xs.append(pos[other][0])
        if parent_xs:
            x = int(sum(parent_xs) / len(parent_xs))
        else:
            x = preferred_host_x.get(n, 220 + i * 210)
        pos[n] = (x, y_by_group["host"])

    for group in ["unknown"]:
        spread(group, 280, 1720)
    return pos


def build_topology_svg(devices: List[Dict[str, Any]], tables: Dict[str, List[Dict[str, Any]]], status_by_device: Dict[str, str] | None = None,
                       expected_topology: Dict[str, Any] | None = None, show_missing: bool = True) -> str:
    status_by_device = status_by_device or {}
    expected_topology = expected_topology or {"devices": {}, "expected_links": []}
    ordered = order_devices(devices)
    device_map = {short_name(d.get("name")): d for d in ordered if short_name(d.get("name"))}
    edges = lldp_edges(tables)
    pos = _position_nodes(ordered, edges, expected_topology)
    width, node_w, node_h = 2000, 112, 54
    height = max([p[1] for p in pos.values()] + [900]) + 120
    color_by_status = {"GREEN": "#22c55e", "YELLOW": "#f59e0b", "RED": "#ef4444", "GRAY": "#94a3b8"}
    link_color = {"mlag_peer": "#2563eb", "routed_p2p": "#64748b", "trunk": "#7c3aed", "access": "#0ea5e9", "parallel": "#64748b", "link": "#94a3b8"}
    link_label = {"mlag_peer": "MLAG", "routed_p2p": "P2P", "trunk": "trunk", "access": "access", "parallel": "links", "link": ""}
    svg = [f"<div class='topology-wrap'><svg viewBox='0 0 {width} {height}' width='100%' height='{height}' role='img'>"]
    svg.append("<defs><filter id='shadow'><feDropShadow dx='0' dy='3' stdDeviation='3' flood-opacity='.18'/></filter></defs>")
    # row labels
    for label, y in [("Routers",80),("Spines",255),("Leafs",455),("Memleafs",650),("Hosts",835)]:
        svg.append(f"<text x='35' y='{y+5}' fill='#64748b' font-size='18' font-weight='800'>{label}</text>")
        svg.append(f"<line x1='140' y1='{y}' x2='{width-60}' y2='{y}' stroke='#e5e7eb' stroke-dasharray='4 7'/>")
    # actual links
    for (a,b), rows in sorted(edges.items()):
        if a not in pos or b not in pos:
            continue
        x1,y1=pos[a]; x2,y2=pos[b]
        lt = infer_link_type(a,b,rows,tables,expected_topology)
        color = link_color.get(lt, "#94a3b8")
        label = link_label.get(lt, "")
        if lt == "mlag_peer":
            offset = 10
            svg.append(f"<line x1='{x1}' y1='{y1+offset}' x2='{x2}' y2='{y2+offset}' stroke='{color}' stroke-width='3' opacity='.95'/>")
            svg.append(f"<line x1='{x1}' y1='{y1-offset}' x2='{x2}' y2='{y2-offset}' stroke='{color}' stroke-width='3' opacity='.95'/>")
            mx,my=(x1+x2)/2,(y1+y2)/2
            svg.append(f"<circle cx='{mx}' cy='{my}' r='16' fill='#eff6ff' stroke='{color}' stroke-width='2'/>")
            svg.append(f"<text x='{mx}' y='{my+4}' text-anchor='middle' font-size='10' font-weight='800' fill='{color}'>MLAG</text>")
        else:
            # gentle curve for same-tier links, straight for parent-child.
            if abs(y1-y2) < 80:
                c1x,c2x=x1,(x2)
                cy=y1-55
                svg.append(f"<path d='M{x1},{y1} C{c1x},{cy} {c2x},{cy} {x2},{y2}' fill='none' stroke='{color}' stroke-width='2.2' opacity='.9'/>")
            else:
                svg.append(f"<line x1='{x1}' y1='{y1}' x2='{x2}' y2='{y2}' stroke='{color}' stroke-width='2.2' opacity='.88'/>")
            if label:
                mx,my=(x1+x2)/2,(y1+y2)/2
                svg.append(f"<rect x='{mx-24}' y='{my-12}' width='48' height='20' rx='10' fill='#ffffff' stroke='{color}' opacity='.95'/>")
                svg.append(f"<text x='{mx}' y='{my+3}' text-anchor='middle' font-size='10' font-weight='700' fill='{color}'>{esc(label)}</text>")
    # missing expected links
    if show_missing:
        actual_keys = set(edges.keys())
        for link in expected_topology.get("expected_links", []) or []:
            if not isinstance(link, dict) or link.get("required") is False:
                continue
            a,b=short_name(link.get("local_device")), short_name(link.get("remote_device"))
            if not a or not b or edge_key(a,b) in actual_keys or a not in pos or b not in pos:
                continue
            x1,y1=pos[a]; x2,y2=pos[b]
            svg.append(f"<line x1='{x1}' y1='{y1}' x2='{x2}' y2='{y2}' stroke='#ef4444' stroke-width='3' stroke-dasharray='8 7'/>")
            mx,my=(x1+x2)/2,(y1+y2)/2
            svg.append(f"<rect x='{mx-34}' y='{my-12}' width='68' height='20' rx='10' fill='#fee2e2' stroke='#ef4444'/>")
            svg.append(f"<text x='{mx}' y='{my+3}' text-anchor='middle' font-size='10' font-weight='800' fill='#991b1b'>missing</text>")
    # nodes
    for n,d in device_map.items():
        if n not in pos:
            continue
        x,y=pos[n]
        status = status_by_device.get(d.get("name"), status_by_device.get(n, "GRAY"))
        color = color_by_status.get(str(status).upper(), "#94a3b8")
        role = d.get("role", "")
        svg.append(f"<rect x='{x-node_w/2}' y='{y-node_h/2}' width='{node_w}' height='{node_h}' rx='14' fill='#ffffff' stroke='{color}' stroke-width='4' filter='url(#shadow)'/>")
        svg.append(f"<text x='{x}' y='{y-5}' text-anchor='middle' font-size='15' font-weight='850' fill='#111827'>{esc(d.get('name') or n)}</text>")
        svg.append(f"<text x='{x}' y='{y+13}' text-anchor='middle' font-size='10' fill='#64748b'>{esc(role)}</text>")
    svg.append("</svg></div>")
    return "".join(svg)


def lldp_table_rows(tables: Dict[str, List[Dict[str, Any]]], expected_topology: Dict[str, Any] | None = None) -> List[Dict[str, str]]:
    expected_topology = expected_topology or {}
    result = []
    edges = lldp_edges(tables)
    for (a,b), rows in sorted(edges.items(), key=lambda item: (natural_key(item[0][0]), natural_key(item[0][1]))):
        lt = infer_link_type(a,b,rows,tables,expected_topology)
        for r in rows:
            result.append({
                "Device": str(r.get("Device") or ""),
                "Port": str(r.get("Interface") or ""),
                "Neighbor": str(r.get("Neighbor") or ""),
                "Port ID": str(r.get("Neighbor Port") or ""),
                "Link Type": lt.replace("_", " "),
                "Status": "Observed",
            })
    return result
