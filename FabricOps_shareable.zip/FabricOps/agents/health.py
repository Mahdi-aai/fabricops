from __future__ import annotations

import hashlib
import ipaddress
import re
from typing import Any, Dict, List, Tuple


def _s(value: Any) -> str:
    return "" if value is None else str(value).strip()


def _norm_state(value: Any) -> str:
    return _s(value).lower()


def _finding_id(category: str, device: str, problem: str, evidence_key: str = "") -> str:
    # Keep acceptance scoped to the exact current condition. If the neighbor, port,
    # evidence, or problem changes in the next run, the previous checkbox will not hide it.
    raw = f"{category}|{device}|{problem}|{evidence_key[:180]}".encode("utf-8", "ignore")
    return hashlib.sha1(raw).hexdigest()[:12]


def _plain_text(category: str, problem: str) -> str:
    c = _s(category).lower()
    if c == "bgp":
        return "This device has a routing neighbor configured, but the session is not up. Routes may not be exchanged over that link."
    if c == "evpn":
        return "The overlay control-plane session is not fully up. MAC, IP, or VNI information may not be shared correctly."
    if c == "ospf":
        return "This routing neighbor is not fully formed, so the two devices may not be exchanging routes correctly."
    if c == "mlag":
        return "The paired-switch redundancy state needs attention. A peer link or MLAG setting may not be healthy."
    if c == "host link":
        return "This host is known, but FabricOps cannot see an active physical neighbor connection for it right now."
    if c == "interface":
        return "A port is reporting errors or drops. This may point to a cable, optic, speed, or peer-port issue."
    if c == "eapi":
        return "FabricOps could not read live show-command data from this device."
    if c == "cloudvision":
        return "CloudVision does not show this device as actively streaming."
    return problem


def _add(findings: List[Dict[str, Any]], severity: str, category: str, device: str,
         problem: str, action: str, evidence: Any = "", config_hint: str = "",
         peer_device: str = "", plain_english: str = "") -> None:
    evidence_text = _s(evidence)
    finding = {
        "Finding ID": _finding_id(category, device, problem, evidence_text),
        "Severity": severity,
        "Category": category,
        "Device": device,
        "Peer Device": peer_device,
        "Problem": problem,
        "Plain English": plain_english or _plain_text(category, problem),
        "Evidence": evidence_text,
        "Recommended Action": action,
        "Configuration Hint": config_hint,
    }
    findings.append(finding)


def _interface_ip(address: str) -> str:
    text = _s(address)
    if not text:
        return ""
    token = text.split()[0]
    if "/" not in token:
        return token if re.match(r"^\d+\.\d+\.\d+\.\d+$", token) else ""
    try:
        return str(ipaddress.ip_interface(token).ip)
    except Exception:
        return token.split("/")[0]


def _build_ip_maps(tables: Dict[str, List[Dict[str, Any]]]) -> Tuple[Dict[str, str], Dict[str, List[str]]]:
    ip_to_device: Dict[str, str] = {}
    device_to_ips: Dict[str, List[str]] = {}
    for row in tables.get("ip_interfaces", []):
        device = _s(row.get("Device"))
        ip = _interface_ip(row.get("Address", ""))
        if device and ip:
            ip_to_device[ip] = device
            device_to_ips.setdefault(device, []).append(ip)
    return ip_to_device, device_to_ips


def _short_name(value: Any) -> str:
    text = _s(value).split()[0].split(".")[0].lower()
    return text


def _device_group(name: Any, role: Any = "") -> str:
    n = _short_name(name)
    r = _s(role).lower()
    if "router" in n or "router" in r:
        return "router"
    if "spine" in n or "spine" in r:
        return "spine"
    if "memleaf" in n or "memleaf" in r:
        return "memleaf"
    if n.startswith("leaf") or "leaf" in r:
        return "leaf"
    if "host" in n or "host" in r:
        return "host"
    return "other"


def _mlag_row_has_real_evidence(row: Dict[str, Any]) -> bool:
    """Return True only when a parsed MLAG row has real MLAG evidence.

    Routers and pure L3 devices often return disabled/not-configured MLAG output.
    That output should not be treated as an MLAG requirement or an MLAG problem.
    """
    state = _s(row.get("State")).lower()
    peer = _s(row.get("Peer"))
    local = _s(row.get("Local Intf"))
    peer_link = _s(row.get("Peer Link"))
    consistency = _s(row.get("Consistency"))
    combined = " ".join([state, peer, local, peer_link, consistency]).lower()
    if any(x in combined for x in ["not configured", "not enabled", "mlag disabled", "disabled"]) and not (peer or local or peer_link):
        return False
    return bool(peer or local or peer_link or consistency or "active" in state or "configured" in combined or "peer" in combined)


def _device_should_be_checked_for_mlag(device: str, devices: List[Dict[str, Any]], tables: Dict[str, List[Dict[str, Any]]]) -> bool:
    """Only validate MLAG where MLAG is actually configured or clearly expected.

    Layer-3 routers and pure Layer-3 spine devices must not be marked yellow for
    MLAG if MLAG is not part of their design.
    """
    dshort = _short_name(device)
    device_obj = next((d for d in devices if _short_name(d.get("name")) == dshort), {})
    group = _device_group(device_obj.get("name", device), device_obj.get("role", ""))
    if group in {"router", "host"}:
        return False

    # Real parsed MLAG evidence is enough to check MLAG.
    for row in tables.get("mlag", []):
        if _short_name(row.get("Device")) == dshort and _mlag_row_has_real_evidence(row):
            return True

    # Interface/Port-Channel descriptions can also indicate MLAG on leaf/memleaf pairs.
    for key in ("interfaces", "port_channels"):
        for row in tables.get(key, []):
            if _short_name(row.get("Device")) != dshort:
                continue
            text = str(row).lower()
            if "mlag" in text and ("peer" in text or "port-channel" in text or "po" in text):
                return True

    return False


def _is_up_status(value: Any) -> bool:
    s = _s(value).lower()
    return s in {"up", "connected", "active"} or "connected" in s


def _interface_for_host(host_name: str, tables: Dict[str, List[Dict[str, Any]]]) -> Dict[str, Any]:
    host_l = _short_name(host_name)
    host_num = "".join(ch for ch in host_l if ch.isdigit())
    for row in tables.get("interfaces", []):
        desc = _s(row.get("Description")).lower().replace("-", "_")
        device = _s(row.get("Device")).lower()
        intf = _s(row.get("Interface")).lower()
        if device == host_l:
            continue
        if host_l and host_l in desc:
            return row
        if host_num and (f"host{host_num}" in desc or f"host_{host_num}" in desc):
            return row
        if host_num and f"_h{host_num}" in desc:
            return row
    return {}


def _bgp_peer_context(row: Dict[str, Any], tables: Dict[str, List[Dict[str, Any]]]) -> Tuple[str, str, str]:
    """Return peer device, peer problem sentence, and config hint."""
    device = _s(row.get("Device"))
    neighbor = _s(row.get("Neighbor"))
    remote_as = _s(row.get("ASN"))
    afi = _s(row.get("AFI")) or "IPv4"
    ip_to_device, device_to_ips = _build_ip_maps(tables)
    peer_device = ip_to_device.get(neighbor, "")

    peer_sentence = ""
    if peer_device:
        original_ips = set(device_to_ips.get(device, []))
        reciprocal = [r for r in tables.get("bgp", [])
                      if _s(r.get("Device")) == peer_device and _s(r.get("Neighbor")) in original_ips]
        if reciprocal:
            peer_state = ", ".join(f"{r.get('Neighbor')}={r.get('State')}" for r in reciprocal)
            peer_sentence = f"Peer IP {neighbor} maps to {peer_device}; reciprocal BGP evidence on {peer_device}: {peer_state}."
        else:
            peer_sentence = f"Peer IP {neighbor} maps to {peer_device}, but no reciprocal BGP neighbor pointing back to {device} was found in collected data."
    else:
        peer_sentence = f"Peer IP {neighbor} was not mapped to a collected device interface. It may be an unused/expected peer, a missing device, or an addressing mismatch."

    if afi.lower() == "evpn":
        hint = (
            f"router bgp <local-as>\n"
            f"   neighbor {neighbor} remote-as {remote_as or '<remote-as>'}\n"
            f"   neighbor {neighbor} update-source Loopback0\n"
            f"   neighbor {neighbor} ebgp-multihop 3\n"
            "   address-family evpn\n"
            f"      neighbor {neighbor} activate\n"
            f"      neighbor {neighbor} send-community extended\n! Also verify underlay reachability to the peer loopback."
        )
    else:
        hint = (
            f"router bgp <local-as>\n"
            f"   neighbor {neighbor} remote-as {remote_as or '<remote-as>'}\n"
            f"   neighbor {neighbor} description <peer-device>\n"
            "   address-family ipv4\n"
            f"      neighbor {neighbor} activate\n! Then verify the local routed interface IP, peer routed interface IP, and reciprocal neighbor statement on the peer."
        )
    return peer_device, peer_sentence, hint


def analyze_health(devices: List[Dict[str, Any]], device_results: List[Dict[str, Any]],
                   tables: Dict[str, List[Dict[str, Any]]], live_mode: bool) -> Tuple[Dict[str, Any], List[Dict[str, Any]], List[Dict[str, Any]]]:
    findings: List[Dict[str, Any]] = []

    for d in devices:
        name = _s(d.get("name")) or "UNKNOWN"
        if not d.get("cloudvision_active"):
            _add(
                findings, "RED", "CloudVision", name,
                "Device is not actively streaming to CloudVision.",
                f"Check onboarding, telemetry, CVP reachability, and management connectivity for {name}.",
                d.get("streaming_status", "UNKNOWN"),
                "show daemon TerminAttr; show management api http-commands; verify CloudVision certificate/token and management VRF reachability.",
            )

    if live_mode:
        for result in device_results:
            name = _s((result.get("device") or {}).get("name")) or "UNKNOWN"
            if not result.get("reachable"):
                _add(
                    findings, "RED", "eAPI", name,
                    "EOS eAPI collection failed or device was not reachable.",
                    f"On {name}, verify management IP, HTTPS eAPI on port 443, credentials, SSL verification setting, and management VRF.",
                    result.get("error", ""),
                    "management api http-commands\n   protocol https port 443\n   no shutdown\n   vrf management\n      no shutdown",
                )

    for row in tables.get("bgp", []):
        state = _norm_state(row.get("State"))
        neighbor = _s(row.get("Neighbor"))
        device = _s(row.get("Device")) or "fabric"
        if state and not any(x in state for x in ["established", "estab"]) and not state.isdigit():
            peer_device, peer_sentence, hint = _bgp_peer_context(row, tables)
            _add(
                findings, "YELLOW", "BGP", device,
                f"BGP neighbor {neighbor} is {row.get('State')} instead of Established.",
                f"On {device}, check neighbor {neighbor}: peer reachability, remote ASN {row.get('ASN','')}, source interface, and reciprocal peer configuration. {peer_sentence}",
                row,
                hint,
                peer_device,
            )

    for row in tables.get("evpn", []):
        state = _norm_state(row.get("State"))
        neighbor = _s(row.get("Neighbor"))
        device = _s(row.get("Device")) or "fabric"
        if state and not any(x in state for x in ["established", "estab"]) and not state.isdigit():
            peer_device, peer_sentence, hint = _bgp_peer_context(row, tables)
            _add(
                findings, "YELLOW", "EVPN", device,
                f"EVPN neighbor {neighbor} is {row.get('State')} instead of Established.",
                f"On {device}, verify EVPN peer {neighbor}, update-source loopback, route-reflector relationship, and underlay reachability. {peer_sentence}",
                row,
                hint,
                peer_device,
            )

    for row in tables.get("ospf", []):
        state = _norm_state(row.get("State"))
        device = _s(row.get("Device")) or "fabric"
        if state and "full" not in state:
            iface = _s(row.get("Interface"))
            _add(
                findings, "YELLOW", "OSPF", device,
                f"OSPF neighbor {row.get('Neighbor')} is not Full.",
                f"On {device}, verify OSPF area, MTU, timers, network type, and interface {iface}.",
                row,
                f"On {device}: show ip ospf interface {iface}; verify matching area, MTU, timers, passive-interface, and network type on both ends.",
            )

    for row in tables.get("mlag", []):
        text = str(row).lower()
        device = _s(row.get("Device")) or "fabric"
        # Do not judge routers, hosts, or pure L3 devices for MLAG when there is no real MLAG evidence.
        if not _device_should_be_checked_for_mlag(device, devices, tables):
            continue
        if not _mlag_row_has_real_evidence(row):
            continue
        if any(w in text for w in ["inactive", "down", "inconsistent", "negotiating", "error", "failed"]):
            _add(
                findings, "YELLOW", "MLAG", device,
                "MLAG state appears unhealthy.",
                f"On {device}, MLAG is actually present, but its state needs attention. Check the peer-link, VLAN4094, local-interface, peer address, and config-sanity output.",
                row,
                "show mlag; show mlag config-sanity; show interfaces Port-Channel1; verify VLAN4094 SVI and peer-link trunk group on both MLAG peers.",
            )

    for row in tables.get("interface_errors", []):
        device = _s(row.get("Device")) or "fabric"
        interface = _s(row.get("Interface"))
        _add(
            findings, "YELLOW", "Interface", device,
            f"Interface {interface} has non-zero error or discard counters.",
            f"On {device}, inspect {interface}: cabling, optics, speed/duplex, port-channel membership, and recent logs.",
            row,
            f"show interfaces {interface}; show logging last 100 | include {interface}; verify cable/optic and the connected peer port.",
        )

    for row in tables.get("vxlan", []):
        if _s(row.get("Status")).upper() == "DOWN":
            device = _s(row.get("Device")) or "fabric"
            _add(
                findings, "YELLOW", "VXLAN", device,
                "VXLAN interface or VTEP evidence indicates DOWN.",
                f"On {device}, verify VTEP loopback reachability, underlay routes, EVPN peers, VXLAN interface, VNIs, and VLAN/VRF mappings.",
                row,
                "interface Vxlan1\n   vxlan source-interface Loopback1\n   vxlan vlan <vlan> vni <vni>\n   vxlan vrf <vrf> vni <l3-vni>",
            )

    # Host reachability/visibility from LLDP. If a host loses its physical link,
    # it should be red even if it still exists in inventory.
    lldp_nodes = set()
    for row in tables.get("lldp", []):
        lldp_nodes.add(_short_name(row.get("Device")))
        lldp_nodes.add(_short_name(row.get("Neighbor")))
    for d in devices:
        name = _s(d.get("name")) or "UNKNOWN"
        if _device_group(name, d.get("role")) != "host":
            continue
        short = _short_name(name)
        if short and short not in lldp_nodes:
            ref = _interface_for_host(name, tables)
            if ref:
                sw = _s(ref.get("Device"))
                intf = _s(ref.get("Interface"))
                status = _s(ref.get("Status"))
                action = (
                    f"{name} has no active LLDP edge. The likely access port is {sw} {intf} "
                    f"and its current status is '{status or 'unknown'}'. Check cabling and confirm the port is enabled."
                )
                hint = f"interface {intf}\n   description {name}_access\n   no shutdown" if intf else "show lldp neighbors; show interfaces status"
                evidence = {"Likely Switch": sw, "Interface": intf, "Status": status, "Description": ref.get("Description", "")}
            else:
                action = f"{name} has no active LLDP edge. Check the host link, the connected switch access port, and LLDP visibility."
                hint = "show lldp neighbors; show interfaces status"
                evidence = "No LLDP neighbor edge found for this host."
            _add(
                findings, "RED", "Host Link", name,
                f"No active LLDP connection was detected for {name}.",
                action, evidence, hint,
                plain_english=f"{name} is still in the inventory, but FabricOps cannot see a live physical connection for it. It may be unplugged, shut down, or connected to a port that is down.",
            )

    device_names = [_s(d.get("name")) for d in devices if _s(d.get("name"))]
    red_devices = sorted({f["Device"] for f in findings if f["Severity"] == "RED"})
    yellow_devices = sorted({f["Device"] for f in findings if f["Severity"] == "YELLOW" and f["Device"] not in red_devices})
    green_devices = sorted([d for d in device_names if d not in red_devices and d not in yellow_devices])

    health = {
        "status": "RED" if red_devices else ("YELLOW" if yellow_devices else "GREEN"),
        "live_mode": live_mode,
        "devices_checked": len(devices),
        "cloudvision_active": sum(1 for d in devices if d.get("cloudvision_active")),
        "eapi_reachable": sum(1 for r in device_results if r.get("reachable")) if live_mode else "Not tested",
        "red_devices": red_devices,
        "yellow_devices": yellow_devices,
        "green_devices": green_devices,
        "red_count": len(red_devices),
        "yellow_count": len(yellow_devices),
        "green_count": len(green_devices),
        "findings_count": len(findings),
    }
    recommendations = [{k: f.get(k, "") for k in ["Severity", "Device", "Problem", "Recommended Action", "Configuration Hint"]} for f in findings]
    return health, findings, recommendations


def recompute_device_health(devices: List[Dict[str, Any]], findings: List[Dict[str, Any]], accepted_ids: set[str]) -> Dict[str, Any]:
    """Recalculate device health after the user accepts findings.

    This function must not re-run validation or add new findings. Validation happens
    in analyze_health(), where the command tables are available. This function only
    filters the existing findings by the current-run accepted checkbox state.
    """
    accepted_ids = accepted_ids or set()
    device_names = [_s(d.get("name")) for d in devices if _s(d.get("name"))]

    active_findings = [f for f in findings if f.get("Finding ID") not in accepted_ids]
    red_devices = sorted({f["Device"] for f in active_findings if f.get("Severity") == "RED"})
    yellow_devices = sorted({
        f["Device"] for f in active_findings
        if f.get("Severity") == "YELLOW" and f.get("Device") not in red_devices
    })
    green_devices = sorted([d for d in device_names if d not in red_devices and d not in yellow_devices])

    status_by_device = {d: "GREEN" for d in device_names}
    for d in yellow_devices:
        status_by_device[d] = "YELLOW"
    for d in red_devices:
        status_by_device[d] = "RED"

    return {
        "red_devices": red_devices,
        "yellow_devices": yellow_devices,
        "green_devices": green_devices,
        "red_count": len(red_devices),
        "yellow_count": len(yellow_devices),
        "green_count": len(green_devices),
        "status_by_device": status_by_device,
        "active_findings": active_findings,
        "accepted_count": len(findings) - len(active_findings),
    }
