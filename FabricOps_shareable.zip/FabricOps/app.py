from __future__ import annotations

import html
import json
import re
import time
from datetime import datetime
from typing import Any, Dict, List, Tuple

import streamlit as st
from streamlit.components.v1 import html as st_html

from agents.health import analyze_health, recompute_device_health
from collectors.cloudvision import CloudVisionClient, join_inventory
from collectors.eapi import run_show_commands
from parsers.eos import build_technical_tables
from profiles import HEALTH_PROFILES, build_commands
from reports.html_report import build_html_report
from utils.formatting import clean

APP_NAME = "FabricOps"
DESCRIPTION = "A local dashboard for Arista CloudVision and EOS eAPI read-only fabric validation."
DATA_DIR = "fabricops_data"

st.set_page_config(page_title=APP_NAME, page_icon="▣", layout="wide")

# -----------------------------
# Small utilities
# -----------------------------

def esc(value: Any) -> str:
    if value is None:
        return ""
    text = str(value)
    if text.strip().lower() in {"none", "null", "[]", "{}", "n/a"}:
        return ""
    return html.escape(text)


def short_name(value: Any) -> str:
    return str(value or "").strip().split()[0].split(".")[0].lower()


ROLE_ORDER = {"router": 0, "spine": 1, "leaf": 2, "memleaf": 3, "host": 4, "other": 9}
ROLE_LABELS = {"router": "Routers", "spine": "Spines", "leaf": "Leafs", "memleaf": "Memleafs", "host": "Hosts", "other": "Other"}


def device_group(name: Any, role: Any = "") -> str:
    n = str(name or "").lower()
    r = str(role or "").lower()
    if "router" in n or "router" in r:
        return "router"
    if "spine" in n or "spine" in r:
        return "spine"
    if "memleaf" in n or "memleaf" in r:
        return "memleaf"
    if n.startswith("leaf") or "leaf" in r:
        return "leaf"
    if "host" in n or "host" in r:
        return "host"
    return "other"


def natural_key(value: Any) -> tuple:
    text = str(value or "").lower()
    return tuple(int(p) if p.isdigit() else p for p in re.split(r"(\d+)", text))


def device_sort_key(device_or_name: Any) -> tuple:
    if isinstance(device_or_name, dict):
        name = device_or_name.get("name", "")
        role = device_or_name.get("role", "")
    else:
        name = str(device_or_name or "")
        role = ""
    group = device_group(name, role)
    return (ROLE_ORDER.get(group, 9), natural_key(name))


def ordered_devices(devices: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    return sorted(devices or [], key=device_sort_key)


def rows_for(tables: Dict[str, List[Dict[str, Any]]], key: str, device: str) -> List[Dict[str, Any]]:
    return [r for r in tables.get(key, []) if str(r.get("Device", "")).lower() == str(device).lower()]


def clean_port_id(value: Any) -> str:
    """Keep LLDP port fields human readable instead of showing raw EOS dictionaries."""
    if value is None:
        return ""
    if isinstance(value, dict):
        for k in ("interfaceId_v2", "interfaceId", "portId", "neighborPortId", "name", "interface", "ifName", "value"):
            if value.get(k):
                return clean_port_id(value.get(k))
        return ""
    if isinstance(value, list):
        return ", ".join(clean_port_id(x) for x in value if clean_port_id(x))
    text = str(value).strip()
    # EOS sometimes returns quoted strings like '"Ethernet7"'
    text = text.strip("'").strip('"')
    # If a dictionary got stringified, try to extract interfaceId_v2 or interfaceId.
    if text.startswith("{") and ("interfaceId" in text or "interfaceId_v2" in text):
        for pat in [r"'interfaceId_v2':\s*'([^']+)'", r'"interfaceId_v2":\s*"([^"]+)"', r"'interfaceId':\s*'\"?([^'\"]+)\"?'", r'"interfaceId":\s*"\\?"?([^"}]+)']:
            m = re.search(pat, text)
            if m:
                return clean_port_id(m.group(1))
        return ""
    return text


def friendly_lldp_rows(rows: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    out: List[Dict[str, Any]] = []
    seen = set()
    for row in rows or []:
        item = {
            "Device": clean(row.get("Device")),
            "Port": clean_port_id(row.get("Interface")),
            "Neighbor": clean(row.get("Neighbor")),
            "Port ID": clean_port_id(row.get("Neighbor Port")),
            "Link Type": classify_link_simple(row),
            "Status": "Up",
        }
        key = tuple(item.values())
        if item["Device"] and item["Neighbor"] and key not in seen:
            seen.add(key)
            out.append(item)
    return sorted(out, key=lambda r: (device_sort_key(r["Device"]), natural_key(r["Port"]), device_sort_key(r["Neighbor"])))


def classify_link_simple(row: Dict[str, Any]) -> str:
    a = str(row.get("Device", "")).lower()
    b = str(row.get("Neighbor", "")).lower()
    ports = f"{row.get('Interface','')} {row.get('Neighbor Port','')}".lower()
    if "port-channel" in ports or re.search(r"\bpo\d+\b", ports):
        return "Port-channel"
    if "host" in a or "host" in b:
        return "Access"
    if "router" in a or "router" in b:
        return "Routed P2P"
    if "spine" in a and "spine" in b:
        return "Routed P2P"
    return "Link"


def table_html(rows: List[Dict[str, Any]], columns: List[str] | None = None, max_rows: int | None = None) -> str:
    if not rows:
        return "<div class='empty-state'>No data for this section.</div>"
    visible = rows[:max_rows] if max_rows else rows
    columns = columns or list(dict.fromkeys(k for r in visible for k in r.keys()))
    body = []
    for row in visible:
        cells = []
        for col in columns:
            val = row.get(col, "")
            if col.lower() == "severity":
                cells.append(f"<td>{severity_badge(val)}</td>")
            elif col.lower() in {"status", "state"}:
                cells.append(f"<td>{state_pill(val)}</td>")
            else:
                cells.append(f"<td>{esc(val)}</td>")
        body.append("<tr>" + "".join(cells) + "</tr>")
    more = "" if not max_rows or len(rows) <= max_rows else f"<div class='table-note'>Showing {max_rows} of {len(rows)} rows.</div>"
    return "<div class='table-wrap'><table class='fabric-table'><thead><tr>" + "".join(f"<th>{esc(c)}</th>" for c in columns) + "</tr></thead><tbody>" + "".join(body) + "</tbody></table></div>" + more


def pill(label: Any, color: str = "neutral") -> str:
    return f"<span class='pill pill-{color}'>{esc(label)}</span>"


def state_pill(value: Any) -> str:
    s = str(value or "").strip()
    low = s.lower()
    if not s:
        return ""
    if any(x in low for x in ["established", "connected", "active", "up", "full", "ok", "present"]):
        return pill(s, "green")
    if any(x in low for x in ["idle", "active", "warning", "notconnect", "down", "error", "disabled", "inactive"]):
        return pill(s, "yellow")
    return pill(s, "neutral")


def severity_badge(value: Any) -> str:
    sev = str(value or "").upper()
    if sev == "RED":
        return pill("Red", "red")
    if sev in {"YELLOW", "WARNING", "ATTENTION"}:
        return pill("Yellow", "yellow")
    if sev == "GREEN":
        return pill("Green", "green")
    return pill(sev or "Info", "neutral")


# -----------------------------
# Theme
# -----------------------------

def inject_theme(style: str) -> None:
    dark = style == "Dark"
    pal = {
        "bg": "#172033" if dark else "#f8fafc",
        "sidebar": "#111827" if dark else "#ffffff",
        "panel": "#1f2937" if dark else "#ffffff",
        "panel2": "#253244" if dark else "#f9fafb",
        "text": "#e5e7eb" if dark else "#111827",
        "muted": "#aeb8c8" if dark else "#667085",
        "border": "#39465c" if dark else "#e5e7eb",
        "head": "#263449" if dark else "#f1f5f9",
        "blue": "#60a5fa" if dark else "#2563eb",
        "green": "#22c55e",
        "yellow": "#f59e0b",
        "red": "#ef4444",
        "shadow": "0 10px 24px rgba(2,6,23,.22)" if dark else "0 10px 22px rgba(15,23,42,.06)",
    }
    css = """
    <style>
    :root { --bg:__bg__; --sidebar:__sidebar__; --panel:__panel__; --panel2:__panel2__; --text:__text__; --muted:__muted__; --border:__border__; --head:__head__; --blue:__blue__; --green:__green__; --yellow:__yellow__; --red:__red__; --shadow:__shadow__; }
    .stApp { background:var(--bg) !important; color:var(--text) !important; }
    [data-testid="stSidebar"] { background:var(--sidebar) !important; border-right:1px solid var(--border); }
    #MainMenu, footer, [data-testid="stDecoration"], .stDeployButton { display:none !important; visibility:hidden !important; }
    header [data-testid="stToolbar"] { visibility:hidden !important; height:0 !important; }
    h1,h2,h3,h4,h5,h6,p,span,label,div { color:inherit; }
    .block-container { padding-top:1.2rem; max-width:1500px; }
    .hero { background:var(--panel); border:1px solid var(--border); border-radius:18px; padding:22px 24px; margin:0 0 18px 0; box-shadow:var(--shadow); }
    .hero h1 { margin:0 0 6px 0; font-size:30px; letter-spacing:-.03em; color:var(--text); }
    .hero p { margin:0; color:var(--muted); font-size:15px; }
    .card { background:var(--panel); border:1px solid var(--border); border-radius:16px; padding:18px; margin:12px 0; box-shadow:var(--shadow); }
    .card h3 { margin:0 0 10px 0; }
    .muted { color:var(--muted); }
    .tiny { color:var(--muted); font-size:12px; }
    .metric-grid { display:grid; grid-template-columns:repeat(4,minmax(160px,1fr)); gap:14px; margin:12px 0 20px 0; }
    .metric-card { background:var(--panel); border:1px solid var(--border); border-radius:16px; padding:16px; box-shadow:var(--shadow); }
    .metric-label { color:var(--muted); font-size:12px; text-transform:uppercase; letter-spacing:.06em; font-weight:700; }
    .metric-value { color:var(--text); font-size:30px; font-weight:850; margin-top:5px; }
    .section-label { color:var(--muted); font-size:12px; text-transform:uppercase; letter-spacing:.08em; font-weight:800; margin:20px 0 8px; }
    .device-grid { display:grid; grid-template-columns:repeat(auto-fit,minmax(160px,1fr)); gap:10px; margin-bottom:10px; }
    .device-tile { background:var(--panel); border:1px solid var(--border); border-radius:14px; padding:12px; box-shadow:var(--shadow); }
    .device-name { font-weight:850; margin-top:8px; color:var(--text); }
    .device-meta { color:var(--muted); font-size:12px; margin-top:3px; }
    .pill { display:inline-block; padding:4px 9px; border-radius:999px; font-size:11px; font-weight:800; border:1px solid var(--border); white-space:nowrap; }
    .pill-green { background:rgba(34,197,94,.14); color:var(--green); border-color:rgba(34,197,94,.4); }
    .pill-yellow { background:rgba(245,158,11,.16); color:var(--yellow); border-color:rgba(245,158,11,.45); }
    .pill-red { background:rgba(239,68,68,.16); color:var(--red); border-color:rgba(239,68,68,.45); }
    .pill-neutral { background:var(--panel2); color:var(--text); border-color:var(--border); }
    .table-wrap { overflow:auto; border:1px solid var(--border); border-radius:14px; background:var(--panel); margin:10px 0 16px 0; }
    table.fabric-table { width:100%; border-collapse:separate; border-spacing:0; font-size:13px; min-width:760px; }
    table.fabric-table th { background:var(--head); color:var(--text); border-bottom:1px solid var(--border); padding:10px 12px; text-align:left; position:sticky; top:0; z-index:1; }
    table.fabric-table td { color:var(--text); border-bottom:1px solid var(--border); padding:9px 12px; vertical-align:top; }
    table.fabric-table tr:last-child td { border-bottom:0; }
    .empty-state { background:var(--panel2); color:var(--muted); border:1px dashed var(--border); border-radius:14px; padding:14px; }
    .table-note { color:var(--muted); font-size:12px; margin-top:6px; }
    .finding-card { background:var(--panel); border:1px solid var(--border); border-left:5px solid var(--yellow); border-radius:14px; padding:14px; margin:10px 0; }
    .finding-card.red { border-left-color:var(--red); }
    .config { background:#0f172a; color:#e5e7eb; border:1px solid #334155; border-radius:12px; padding:12px; overflow:auto; white-space:pre-wrap; }
    .details-native { background:var(--panel2); border:1px solid var(--border); border-radius:12px; padding:10px 12px; margin-top:10px; }
    .details-native summary { cursor:pointer; font-weight:700; }
    [data-testid="stExpander"] { background:var(--panel) !important; border:1px solid var(--border) !important; border-radius:14px !important; }
    div[data-baseweb="select"] > div, input, textarea { background:var(--panel) !important; color:var(--text) !important; border-color:var(--border) !important; }
    .stTextInput input, .stPassword input, .stNumberInput input { background:var(--panel) !important; color:var(--text) !important; }
    .stButton button, .stDownloadButton button { border:1px solid var(--border) !important; background:var(--panel2) !important; color:var(--text) !important; border-radius:10px !important; }
    .stButton button[kind="primary"], .stDownloadButton button[kind="primary"] { background:var(--blue) !important; color:white !important; border-color:var(--blue) !important; }
    </style>
    """
    for k, v in pal.items():
        css = css.replace(f"__{k}__", v)
    st.markdown(css, unsafe_allow_html=True)


# -----------------------------
# Data collection
# -----------------------------

def collect_inventory(cv_url: str, username: str, password: str, verify_ssl: bool) -> List[Dict[str, Any]]:
    cv = CloudVisionClient(cv_url, username, password, verify_ssl=verify_ssl)
    cv.login()
    device_records = cv.get_device_inventory()
    provisioned_records = cv.get_provisioned_devices()
    return ordered_devices(join_inventory(device_records, provisioned_records))


def filter_devices(devices: List[Dict[str, Any]], scope: str, single_device: str, include_hosts: bool) -> List[Dict[str, Any]]:
    selected = ordered_devices(devices)
    if not include_hosts:
        selected = [d for d in selected if device_group(d.get("name"), d.get("role")) != "host"]
    if scope == "All Spines":
        return [d for d in selected if device_group(d.get("name"), d.get("role")) == "spine"]
    if scope == "All Leafs":
        return [d for d in selected if device_group(d.get("name"), d.get("role")) in {"leaf", "memleaf"}]
    if scope == "Single Device":
        target = short_name(single_device)
        return [d for d in selected if short_name(d.get("name")) == target]
    return selected


# -----------------------------
# Report rendering
# -----------------------------

def render_metrics(health: Dict[str, Any], adjusted: Dict[str, Any], tables: Dict[str, List[Dict[str, Any]]]) -> None:
    total = int(health.get("devices_checked") or 0)
    bgp = tables.get("bgp", []) + tables.get("evpn", [])
    bgp_est = sum(1 for r in bgp if "established" in str(r.get("State", "")).lower() or str(r.get("State", "")).isdigit())
    bgp_bad = sum(1 for r in bgp if r.get("State") and not ("established" in str(r.get("State", "")).lower() or str(r.get("State", "")).isdigit()))
    html_block = f"""
    <div class='metric-grid'>
      <div class='metric-card'><div class='metric-label'>Healthy</div><div class='metric-value' style='color:var(--green)'>{adjusted.get('green_count',0)} / {total}</div></div>
      <div class='metric-card'><div class='metric-label'>Attention Needed</div><div class='metric-value' style='color:var(--yellow)'>{adjusted.get('yellow_count',0)}</div></div>
      <div class='metric-card'><div class='metric-label'>Down / Critical</div><div class='metric-value' style='color:var(--red)'>{adjusted.get('red_count',0)}</div></div>
      <div class='metric-card'><div class='metric-label'>BGP / EVPN</div><div class='metric-value'>{bgp_est} up</div><div class='tiny'>{bgp_bad} not established</div></div>
    </div>
    """
    st.markdown(html_block, unsafe_allow_html=True)


def device_role_summary(device: Dict[str, Any], tables: Dict[str, List[Dict[str, Any]]]) -> str:
    name = device.get("name", "")
    grp = device_group(name, device.get("role"))
    bgp = len(rows_for(tables, "bgp", name))
    evpn = len(rows_for(tables, "evpn", name))
    vlan = len([r for r in rows_for(tables, "vlans", name) if str(r.get("VLAN")) not in {"", "1"}])
    mlag = len(rows_for(tables, "mlag", name))
    routed = len([r for r in rows_for(tables, "interfaces", name) if str(r.get("Mode", "")).lower() == "routed"])
    access = len([r for r in rows_for(tables, "interfaces", name) if r.get("VLAN") and str(r.get("Interface", "")).lower().startswith("ethernet")])
    if grp == "router":
        return f"Layer 3 router · {bgp} BGP peers · {routed} routed ports"
    if grp == "spine":
        if vlan or mlag:
            return f"Mixed spine · {bgp} BGP peers · {vlan} VLANs · {mlag} MLAG rows"
        return f"Layer 3 spine · {bgp} BGP peers · {routed} routed ports"
    if grp == "memleaf":
        return f"Access/memleaf · {vlan} VLANs · {access} access ports"
    if grp == "leaf":
        parts = []
        if bgp or evpn or routed: parts.append("Layer 3")
        if vlan or access or mlag: parts.append("Layer 2/Access")
        if evpn: parts.append("Overlay")
        return " / ".join(parts) or "Leaf"
    if grp == "host":
        return "Host / endpoint"
    return "Inventory device"


def render_device_tiles(devices: List[Dict[str, Any]], status_by_device: Dict[str, str], tables: Dict[str, List[Dict[str, Any]]]) -> None:
    for group in ["router", "spine", "leaf", "memleaf", "host", "other"]:
        group_devices = [d for d in ordered_devices(devices) if device_group(d.get("name"), d.get("role")) == group]
        if not group_devices:
            continue
        st.markdown(f"<div class='section-label'>{ROLE_LABELS[group]}</div>", unsafe_allow_html=True)
        cards = []
        for d in group_devices:
            name = d.get("name", "UNKNOWN")
            status = status_by_device.get(name, "GREEN")
            color = {"GREEN": "green", "YELLOW": "yellow", "RED": "red"}.get(status, "neutral")
            cards.append(f"<div class='device-tile'>{pill(status.title(), color)}<div class='device-name'>{esc(name)}</div><div class='device-meta'>{esc(device_role_summary(d, tables))}</div><div class='device-meta'>{esc(d.get('host',''))}</div></div>")
        st.markdown("<div class='device-grid'>" + "".join(cards) + "</div>", unsafe_allow_html=True)


def render_findings(findings: List[Dict[str, Any]], show_config_hints: bool) -> set[str]:
    if "accepted_findings" not in st.session_state:
        st.session_state.accepted_findings = set()
    accepted = set(st.session_state.accepted_findings)
    if not findings:
        st.success("No findings were detected in this run.")
        return accepted

    ids = [f.get("Finding ID", "") for f in findings if f.get("Finding ID")]
    c1, c2, c3 = st.columns([1, 1, 4])
    with c1:
        if st.button("Accept all for this run"):
            accepted = set(ids)
            st.session_state.accepted_findings = set(ids)
            for fid in ids:
                st.session_state[f"accept_{fid}"] = True
    with c2:
        if st.button("Clear accepted"):
            accepted = set()
            st.session_state.accepted_findings = set()
            for fid in ids:
                st.session_state[f"accept_{fid}"] = False
    with c3:
        st.markdown(f"<div class='tiny'>Accepted findings affect this report only. New validation runs clear them. Accepted: {len(accepted)} of {len(ids)}</div>", unsafe_allow_html=True)

    for f in findings:
        fid = f.get("Finding ID", "")
        if fid and f"accept_{fid}" not in st.session_state:
            st.session_state[f"accept_{fid}"] = fid in accepted
        accepted_now = bool(st.session_state.get(f"accept_{fid}", False))
        sev = str(f.get("Severity", "YELLOW")).upper()
        label = "Accepted" if accepted_now else sev.title()
        title = f"{label} · {f.get('Category')} · {f.get('Device')} · {f.get('Problem')}"
        with st.expander(title, expanded=not accepted_now):
            st.markdown(
                f"<div class='finding-card {'red' if sev == 'RED' else ''}'>"
                f"{severity_badge(sev)} &nbsp; <b>{esc(f.get('Problem'))}</b><br><br>"
                f"<b>Simple explanation:</b> {esc(f.get('Plain English') or 'This needs review.')}<br><br>"
                f"<b>Recommended action:</b> {esc(f.get('Recommended Action'))}</div>",
                unsafe_allow_html=True,
            )
            if show_config_hints and f.get("Configuration Hint"):
                st.markdown("**Possible configuration / verification hint**")
                st.markdown(f"<pre class='config'>{esc(f.get('Configuration Hint'))}</pre>", unsafe_allow_html=True)
            evidence = f.get("Evidence", "")
            if evidence:
                st.markdown(f"<details class='details-native'><summary>Technical evidence</summary><pre class='config'>{esc(evidence)}</pre></details>", unsafe_allow_html=True)
            checked = st.checkbox("Accept this finding for this run", key=f"accept_{fid}") if fid else False
            if fid:
                if checked:
                    accepted.add(fid)
                else:
                    accepted.discard(fid)
                st.session_state.accepted_findings = set(accepted)
    return accepted


def render_device_details(devices: List[Dict[str, Any]], tables: Dict[str, List[Dict[str, Any]]], status_by_device: Dict[str, str]) -> None:
    if not devices:
        return
    names = [d.get("name", "") for d in ordered_devices(devices)]
    chosen = st.selectbox("Select a device", names, key="detail_device")
    dev = next((d for d in devices if d.get("name") == chosen), {})
    status = status_by_device.get(chosen, "GREEN")
    st.markdown(f"<div class='card'><h3>{esc(chosen)} &nbsp; {pill(status.title(), {'GREEN':'green','YELLOW':'yellow','RED':'red'}.get(status,'neutral'))}</h3><div class='muted'>{esc(device_role_summary(dev, tables))}</div></div>", unsafe_allow_html=True)

    grp = device_group(chosen, dev.get("role"))
    checks = []
    not_required = []
    if grp in {"router", "spine"}:
        checks += ["Layer 3 routing", "BGP/OSPF if configured", "Routed links", "LLDP"]
        not_required += ["Access ports", "MLAG unless actually configured", "VLANs unless actually configured"]
    elif grp == "memleaf":
        checks += ["VLANs", "Access/trunk ports", "MLAG if paired", "LLDP"]
        not_required += ["BGP", "OSPF", "VXLAN/EVPN"]
    elif grp == "host":
        checks += ["At least one connected link", "LLDP visibility if enabled", "Reachability"]
        not_required += ["BGP", "OSPF", "MLAG", "VXLAN/EVPN"]
    else:
        checks += ["Configured features only", "LLDP", "Interface state"]
        not_required += ["Features not configured for this role"]
    st.markdown("<div class='card'><b>Relevant checks</b><br>" + " · ".join(esc(x) for x in checks) + "<br><br><b>Not required</b><br>" + " · ".join(esc(x) for x in not_required) + "</div>", unsafe_allow_html=True)

    sections = [
        ("Interfaces", "interfaces", ["Device", "Interface", "Status", "VLAN", "Mode", "Speed", "Description"]),
        ("VLANs", "vlans", ["Device", "VLAN", "Name", "Status", "Interfaces"]),
        ("BGP", "bgp", ["Device", "VRF", "Neighbor", "ASN", "State", "Prefixes", "Uptime"]),
        ("OSPF", "ospf", None),
        ("MLAG", "mlag", None),
        ("EVPN", "evpn", None),
        ("VXLAN", "vxlan", None),
        ("LLDP", "lldp", ["Device", "Port", "Neighbor", "Port ID", "Link Type", "Status"]),
    ]
    for title, key, cols in sections:
        if key == "lldp":
            rows = [r for r in friendly_lldp_rows(tables.get("lldp", [])) if r.get("Device") == chosen or r.get("Neighbor") == chosen]
        else:
            rows = rows_for(tables, key, chosen)
        with st.expander(f"{title} ({len(rows)})", expanded=False):
            st.markdown(table_html(rows, columns=cols), unsafe_allow_html=True)


# -----------------------------
# Interactive topology
# -----------------------------

def _has_mlag_evidence(a: str, b: str, tables: Dict[str, List[Dict[str, Any]]], metas: List[Dict[str, Any]]) -> bool:
    a_l, b_l = short_name(a), short_name(b)
    # Strong evidence: show mlag rows mention peer/peer-link/domain and device pair. Do not infer from two physical links alone.
    for row in tables.get("mlag", []):
        dev = short_name(row.get("Device"))
        text = str(row).lower()
        if dev in {a_l, b_l} and "mlag" in text and (a_l in text or b_l in text or "peer" in text):
            # Exclude obvious routed P2P descriptions.
            if "p2p" not in text and "routed" not in text:
                return True
    # Descriptions that explicitly say MLAG_PEER are useful evidence.
    for row in tables.get("interfaces", []):
        dev = short_name(row.get("Device"))
        desc = str(row.get("Description", "")).lower()
        if dev in {a_l, b_l} and ("mlag_peer" in desc or "mlag peer" in desc):
            return True
    return False


def build_edges(lldp_rows: List[Dict[str, Any]], tables: Dict[str, List[Dict[str, Any]]]) -> List[Dict[str, Any]]:
    grouped: Dict[Tuple[str, str], List[Dict[str, Any]]] = {}
    for row in lldp_rows or []:
        a = short_name(row.get("Device"))
        b = short_name(row.get("Neighbor"))
        if not a or not b or a == b:
            continue
        key = tuple(sorted([a, b]))
        grouped.setdefault(key, []).append(row)
    edges = []
    for (a, b), metas in grouped.items():
        link_type = "link"
        label = ""
        if _has_mlag_evidence(a, b, tables, metas):
            link_type = "mlag"
            label = "MLAG"
        elif "host" in a or "host" in b:
            link_type = "access"
            label = "Access"
        elif "router" in a or "router" in b or ("spine" in a and "spine" in b):
            link_type = "p2p"
            label = "P2P"
        else:
            link_type = "trunk" if any("port-channel" in str(m.get("Interface", "")).lower() or "po" in str(m.get("Interface", "")).lower() for m in metas) else "link"
            label = "Trunk" if link_type == "trunk" else ""
        ports = []
        for m in metas[:4]:
            p1 = clean_port_id(m.get("Interface"))
            p2 = clean_port_id(m.get("Neighbor Port"))
            dev = short_name(m.get("Device"))
            if dev == a:
                ports.append(f"{p1} ↔ {p2}")
            else:
                ports.append(f"{p2} ↔ {p1}")
        edges.append({"source": a, "target": b, "type": link_type, "label": label, "ports": "; ".join([p for p in ports if p])})
    return edges


def default_positions(nodes: List[Dict[str, Any]], edges: List[Dict[str, Any]]) -> Dict[str, Dict[str, int]]:
    """Stable umbrella layout tuned for router/spine/leaf/memleaf/host fabrics."""
    pos: Dict[str, Dict[str, int]] = {}
    by: Dict[str, List[str]] = {k: [] for k in ROLE_ORDER}
    for n in nodes:
        by.setdefault(n["group"], []).append(n["id"])
    for k in by:
        by[k] = sorted(by[k], key=natural_key)

    fixed = {
        "router1": (500, 80), "router2": (1040, 80),
        "spine1": (250, 260), "spine2": (520, 260), "spine3": (980, 260), "spine4": (1250, 260),
        "leaf1": (220, 455), "leaf2": (460, 455), "leaf3": (700, 455), "leaf4": (940, 455), "leaf5": (1120, 455),
        "memleaf1": (700, 635), "memleaf2": (940, 635),
        "host1": (220, 815), "host2": (460, 815), "host3": (700, 815), "host4": (940, 815), "host5": (1120, 815),
    }
    for n in nodes:
        if n["id"] in fixed:
            x, y = fixed[n["id"]]
            pos[n["id"]] = {"x": x, "y": y}

    rows = {"router": 80, "spine": 260, "leaf": 455, "memleaf": 635, "host": 815, "other": 940}
    for group, names in by.items():
        missing = [x for x in names if x not in pos]
        if not missing:
            continue
        y = rows.get(group, 940)
        left, right = (380, 1160) if group == "router" else (190, 1330)
        step = (right - left) / max(1, len(missing) - 1)
        if len(missing) == 1:
            xs = [(left + right) // 2]
        else:
            xs = [int(left + i * step) for i in range(len(missing))]
        for name, x in zip(missing, xs):
            pos[name] = {"x": x, "y": y}
    return pos


def build_topology_html(devices: List[Dict[str, Any]], tables: Dict[str, List[Dict[str, Any]]], status_by_device: Dict[str, str], style: str) -> str:
    nodes = []
    for d in ordered_devices(devices):
        name = d.get("name", "")
        sid = short_name(name)
        if not sid:
            continue
        status = status_by_device.get(name, "GREEN")
        group = device_group(name, d.get("role"))
        nodes.append({
            "id": sid,
            "name": name,
            "role": d.get("role") or group,
            "group": group,
            "status": status,
            "summary": device_role_summary(d, tables),
            "mgmt": d.get("host", ""),
        })
    edges = build_edges(tables.get("lldp", []), tables)
    positions = default_positions(nodes, edges)
    dark = style == "Dark"
    colors = {
        "bg": "#172033" if dark else "#f8fafc",
        "panel": "#1f2937" if dark else "#ffffff",
        "text": "#e5e7eb" if dark else "#111827",
        "muted": "#aeb8c8" if dark else "#667085",
        "border": "#39465c" if dark else "#d9e0ea",
        "green": "#22c55e",
        "yellow": "#f59e0b",
        "red": "#ef4444",
        "line": "#94a3b8",
        "p2p": "#60a5fa",
        "access": "#22c55e",
        "trunk": "#a78bfa",
        "mlag": "#2563eb",
    }
    payload = json.dumps({"nodes": nodes, "edges": edges, "positions": positions, "colors": colors}, ensure_ascii=False)
    html_doc = r"""
<!doctype html><html><head><meta charset="utf-8"><style>
  body{margin:0;background:__BG__;font-family:Inter,Arial,sans-serif;color:__TEXT__;}
  .toolbar{display:flex;gap:8px;align-items:center;padding:10px 12px;background:__PANEL__;border:1px solid __BORDER__;border-radius:14px;margin-bottom:10px;}
  button{border:1px solid __BORDER__;background:transparent;color:__TEXT__;border-radius:10px;padding:7px 10px;font-weight:700;cursor:pointer;}
  button:hover{border-color:#60a5fa;}
  .wrap{border:1px solid __BORDER__;background:__PANEL__;border-radius:18px;overflow:hidden;}
  svg{width:100%;height:880px;display:block;cursor:default;}
  .node rect{fill:__PANEL__;stroke-width:3;filter:drop-shadow(0 8px 14px rgba(0,0,0,.12));}
  .node text.name{font-weight:850;font-size:13px;fill:__TEXT__;pointer-events:none;}
  .node text.role{font-size:10px;fill:__MUTED__;pointer-events:none;}
  .node{cursor:grab;}
  .node:active{cursor:grabbing;}
  .row-label{fill:__MUTED__;font-size:12px;font-weight:800;letter-spacing:.08em;text-transform:uppercase;}
  .edge{fill:none;stroke-width:2.1;opacity:.86;cursor:pointer;}
  .edge-label{font-size:10px;fill:__MUTED__;font-weight:700;display:none;pointer-events:none;}
  .show-labels .edge-label{display:block;}
  #detail{padding:12px 14px;background:__PANEL__;border:1px solid __BORDER__;border-radius:14px;margin-top:10px;color:__TEXT__;font-size:13px;line-height:1.45;}
  .muted{color:__MUTED__;}
</style></head><body>
<div class="toolbar">
  <button onclick="saveLayout()">Save layout</button>
  <button onclick="resetLayout()">Reset layout</button>
  <button onclick="autoLayout()">Auto layout</button>
  <label style="display:flex;gap:6px;align-items:center;color:__MUTED__;font-size:13px"><input id="labels" type="checkbox" onchange="toggleLabels()"> Show link labels</label>
  <span class="muted">Drag devices to move them. Click a device or link for details.</span>
</div>
<div class="wrap"><svg id="topo" viewBox="0 0 1500 940" preserveAspectRatio="xMidYMid meet"></svg></div>
<div id="detail" class="muted">Click a device or link to see simple details.</div>
<script>
const DATA = __DATA__;
const KEY = "fabricops-topology-layout-v2";
let positions = JSON.parse(JSON.stringify(DATA.positions));
try { const saved = JSON.parse(localStorage.getItem(KEY) || "{}"); positions = Object.assign(positions, saved); } catch(e) {}
let selected = null, drag = null, offset = {x:0,y:0};
const svg = document.getElementById('topo');
const detail = document.getElementById('detail');
const colorStatus = {GREEN: DATA.colors.green, YELLOW: DATA.colors.yellow, RED: DATA.colors.red};
const edgeColor = {p2p: DATA.colors.p2p, access: DATA.colors.access, trunk: DATA.colors.trunk, mlag: DATA.colors.mlag, link: DATA.colors.line};
function S(tag, attrs){ const e=document.createElementNS('http://www.w3.org/2000/svg', tag); for(const k in attrs){e.setAttribute(k, attrs[k]);} return e; }
function getPos(id){ return positions[id] || {x:750,y:460}; }
function pathFor(a,b){
  const p1=getPos(a), p2=getPos(b); const same=Math.abs(p1.y-p2.y)<30;
  if(same){ return `M ${p1.x+60} ${p1.y} C ${(p1.x+p2.x)/2} ${p1.y-38}, ${(p1.x+p2.x)/2} ${p2.y-38}, ${p2.x-60} ${p2.y}`; }
  const mid=(p1.y+p2.y)/2; return `M ${p1.x} ${p1.y+28} C ${p1.x} ${mid}, ${p2.x} ${mid}, ${p2.x} ${p2.y-28}`;
}
function render(){
  svg.innerHTML='';
  [['Routers',80],['Spines',260],['Leafs',455],['Memleafs',635],['Hosts',815]].forEach(([t,y])=>{ const tx=S('text',{x:28,y:y+5,class:'row-label'}); tx.textContent=t; svg.appendChild(tx); });
  const edgeLayer=S('g',{}); svg.appendChild(edgeLayer);
  DATA.edges.forEach((e,i)=>{
    const path=S('path',{d:pathFor(e.source,e.target),class:'edge',stroke:edgeColor[e.type]||DATA.colors.line,'data-idx':i});
    path.addEventListener('click',()=>showEdge(e)); edgeLayer.appendChild(path);
    const p1=getPos(e.source), p2=getPos(e.target); const lbl=S('text',{x:(p1.x+p2.x)/2,y:(p1.y+p2.y)/2-8,'text-anchor':'middle',class:'edge-label'}); lbl.textContent=e.label || e.type; edgeLayer.appendChild(lbl);
  });
  const nodeLayer=S('g',{}); svg.appendChild(nodeLayer);
  DATA.nodes.forEach(n=>{
    const p=getPos(n.id), color=colorStatus[n.status] || DATA.colors.line;
    const g=S('g',{class:'node','data-id':n.id,transform:`translate(${p.x},${p.y})`});
    const r=S('rect',{x:-62,y:-28,width:124,height:56,rx:12,stroke:color}); g.appendChild(r);
    const dot=S('circle',{cx:-50,cy:-16,r:5,fill:color}); g.appendChild(dot);
    const name=S('text',{x:0,y:-3,'text-anchor':'middle',class:'name'}); name.textContent=n.name; g.appendChild(name);
    const role=S('text',{x:0,y:15,'text-anchor':'middle',class:'role'}); role.textContent=n.role || n.group; g.appendChild(role);
    g.addEventListener('mousedown',(ev)=>{drag=n.id; const pt=mousePoint(ev); offset.x=pt.x-p.x; offset.y=pt.y-p.y;});
    g.addEventListener('click',(ev)=>{ev.stopPropagation(); showNode(n);});
    nodeLayer.appendChild(g);
  });
  if(document.getElementById('labels').checked){ svg.classList.add('show-labels'); } else { svg.classList.remove('show-labels'); }
}
function mousePoint(evt){ const pt=svg.createSVGPoint(); pt.x=evt.clientX; pt.y=evt.clientY; return pt.matrixTransform(svg.getScreenCTM().inverse()); }
svg.addEventListener('mousemove',(ev)=>{ if(!drag) return; const pt=mousePoint(ev); positions[drag]={x:Math.round(pt.x-offset.x),y:Math.round(pt.y-offset.y)}; render(); });
window.addEventListener('mouseup',()=>{drag=null;});
function showNode(n){ detail.innerHTML=`<b>${n.name}</b><br><span class='muted'>Role:</span> ${n.role || n.group}<br><span class='muted'>Status:</span> ${n.status}<br><span class='muted'>Summary:</span> ${n.summary || ''}<br><span class='muted'>Management:</span> ${n.mgmt || ''}`; }
function showEdge(e){ detail.innerHTML=`<b>${e.source} ↔ ${e.target}</b><br><span class='muted'>Type:</span> ${e.type}<br><span class='muted'>Ports:</span> ${e.ports || 'LLDP edge'}<br><span class='muted'>Source:</span> LLDP`; }
function saveLayout(){ localStorage.setItem(KEY, JSON.stringify(positions)); detail.innerHTML='Layout saved in this browser.'; }
function resetLayout(){ localStorage.removeItem(KEY); positions=JSON.parse(JSON.stringify(DATA.positions)); render(); detail.innerHTML='Layout reset to FabricOps auto layout.'; }
function autoLayout(){ positions=JSON.parse(JSON.stringify(DATA.positions)); render(); detail.innerHTML='Auto layout applied. Click Save layout to keep it.'; }
function toggleLabels(){ render(); }
render();
</script></body></html>
"""
    for key, val in {
        "__BG__": colors["bg"], "__PANEL__": colors["panel"], "__TEXT__": colors["text"], "__MUTED__": colors["muted"], "__BORDER__": colors["border"], "__DATA__": payload,
    }.items():
        html_doc = html_doc.replace(key, val)
    return html_doc


# -----------------------------
# App state
# -----------------------------

DEFAULTS = {
    "devices": [], "connected": False, "last_run": None, "device_results": [], "tables": {},
    "health": {}, "findings": [], "recommendations": [], "accepted_findings": set(),
    "cv_url": "", "cv_username": "", "cv_password": "",
    "eapi_username": "", "eapi_password": "", "verify_ssl": False,
}
for key, value in DEFAULTS.items():
    if key not in st.session_state:
        st.session_state[key] = value

# Sidebar navigation only
with st.sidebar:
    st.markdown("## FabricOps")
    page = st.radio("Menu", ["Run Check", "Report", "Topology"], label_visibility="collapsed")
    st.markdown("---")
    style = st.radio("Display style", ["Light", "Dark"], horizontal=True, index=0)
    st.markdown("---")
    st.caption("Session status")
    if st.session_state.connected:
        st.success("CloudVision: Connected")
    else:
        st.warning("CloudVision: Not connected")
    if st.button("Clear session"):
        st.session_state.clear()
        st.rerun()
    st.caption(f"Devices: {len(st.session_state.devices)}")
    st.caption(f"Last run: {st.session_state.last_run or 'Not run'}")

inject_theme(style)
st.markdown(f"<div class='hero'><h1>{APP_NAME}</h1><p>{DESCRIPTION}</p></div>", unsafe_allow_html=True)

# -----------------------------
# Run Check page
# -----------------------------
if page == "Run Check":
    st.subheader("Run Check")
    st.caption("Connection and validation are combined here so credentials are entered once per session.")

    left, right = st.columns([1, 1])
    with left:
        st.markdown("<div class='card'><h3>Connection</h3><div class='muted'>CloudVision and EOS/eAPI access. Passwords are stored only for this session.</div></div>", unsafe_allow_html=True)
        cv_url = st.text_input("CloudVision URL", value=st.session_state.cv_url, placeholder="https://your-cloudvision-host")
        cv_username = st.text_input("CloudVision username", value=st.session_state.cv_username)
        cv_password = st.text_input("CloudVision password", value=st.session_state.cv_password, type="password")
        eapi_username = st.text_input("EOS/eAPI username", value=st.session_state.eapi_username or cv_username)
        eapi_password = st.text_input("EOS/eAPI password", value=st.session_state.eapi_password, type="password")
        verify_ssl = st.checkbox("Verify SSL certificates", value=st.session_state.verify_ssl, help="Keep unchecked for self-signed lab certificates.")
        protocol = st.selectbox("eAPI transport", ["HTTPS 443", "HTTP 80", "Custom"], index=0)
        if protocol == "Custom":
            eapi_protocol = st.selectbox("Protocol", ["https", "http"], index=0)
            eapi_port = st.number_input("Port", min_value=1, max_value=65535, value=443)
        elif protocol == "HTTP 80":
            eapi_protocol, eapi_port = "http", 80
        else:
            eapi_protocol, eapi_port = "https", 443
        save = st.checkbox("Remember these credentials for this session", value=True)

    with right:
        st.markdown("<div class='card'><h3>Validation</h3><div class='muted'>Choose what to check, then run validation.</div></div>", unsafe_allow_html=True)
        profile_name = st.selectbox("Validation profile", list(HEALTH_PROFILES.keys()), index=0)
        scope = st.selectbox("Scope", ["Entire Inventory", "All Spines", "All Leafs", "Single Device"], index=0)
        single_device = st.text_input("Single device name", value="", placeholder="Enter a device name", disabled=scope != "Single Device")
        include_hosts = st.checkbox("Include hosts", value=True)
        run_live = st.checkbox("Run live EOS/eAPI show commands", value=True)
        show_config_hints = st.checkbox("Show optional config hints in report", value=True)
        st.session_state.show_config_hints = show_config_hints
        selected_profile = HEALTH_PROFILES[profile_name]
        profile_description = f"{profile_name}: {len(selected_profile)} read-only show commands."
        st.markdown(f"<div class='card'><b>Selected profile:</b> {esc(profile_description)}<br><span class='tiny'>Commands are read-only show commands.</span></div>", unsafe_allow_html=True)

    btn1, btn2 = st.columns([1, 4])
    with btn1:
        test_clicked = st.button("Test Connection")
    with btn2:
        run_clicked = st.button("Run Check", type="primary")

    if test_clicked or run_clicked:
        if not cv_url or not cv_username or not cv_password:
            st.error("CloudVision URL, username, and password are required.")
        else:
            try:
                if save:
                    st.session_state.cv_url = cv_url
                    st.session_state.cv_username = cv_username
                    st.session_state.cv_password = cv_password
                    st.session_state.eapi_username = eapi_username
                    st.session_state.eapi_password = eapi_password
                    st.session_state.verify_ssl = verify_ssl
                with st.status("Connecting to CloudVision...", expanded=True) as status:
                    st.write("Loading CloudVision inventory")
                    devices = collect_inventory(cv_url, cv_username, cv_password, verify_ssl)
                    st.session_state.devices = devices
                    st.session_state.connected = True
                    st.write(f"Discovered {len(devices)} devices")
                    status.update(label="CloudVision connected", state="complete")
                if test_clicked and not run_clicked:
                    st.success(f"Connected. Devices discovered: {len(devices)}")
                if run_clicked:
                    # Every new run clears current-run accepted findings.
                    st.session_state.accepted_findings = set()
                    for key in list(st.session_state.keys()):
                        if str(key).startswith("accept_"):
                            del st.session_state[key]
                    selected = filter_devices(devices, scope, single_device, include_hosts)
                    device_results: List[Dict[str, Any]] = []
                    if run_live:
                        commands = build_commands(profile_name)
                        progress = st.progress(0, text="Starting live collection")
                        for idx, d in enumerate(selected, start=1):
                            host = d.get("host") or d.get("management_ip") or d.get("ipAddress") or ""
                            progress.progress((idx - 1) / max(1, len(selected)), text=f"Collecting {d.get('name','device')} ({idx}/{len(selected)})")
                            if not host:
                                device_results.append({"device": d, "reachable": False, "error": "Missing management IP", "outputs": {}})
                                continue
                            result = run_show_commands(
                                host=host,
                                username=eapi_username or cv_username,
                                password=eapi_password or cv_password,
                                commands=commands,
                                protocol=eapi_protocol,
                                port=int(eapi_port),
                                verify_ssl=verify_ssl,
                            )
                            result["device"] = d
                            device_results.append(result)
                        progress.progress(1.0, text="Collection complete")
                    else:
                        device_results = [{"device": d, "reachable": False, "error": "Live eAPI disabled", "outputs": {}} for d in selected]
                    tables = build_technical_tables(device_results)
                    health, findings, recommendations = analyze_health(selected, device_results, tables, live_mode=run_live)
                    st.session_state.device_results = device_results
                    st.session_state.tables = tables
                    st.session_state.health = health
                    st.session_state.findings = findings
                    st.session_state.recommendations = recommendations
                    st.session_state.last_run = datetime.now().strftime("%Y-%m-%d %H:%M")
                    st.success(f"Validation complete. {health.get('green_count',0)} healthy, {health.get('yellow_count',0)} attention needed, {health.get('red_count',0)} down/critical.")
                    st.info("Use the left sidebar to open Report or Topology.")
            except Exception as exc:
                st.error(f"FabricOps could not complete the request: {exc}")

    if st.session_state.devices:
        st.markdown("### Inventory preview")
        preview = [{"Device": d.get("name"), "Role": d.get("role"), "Management IP": d.get("host"), "Status": "Active" if d.get("cloudvision_active") else "Not active"} for d in ordered_devices(st.session_state.devices)]
        st.markdown(table_html(preview, ["Device", "Role", "Management IP", "Status"], max_rows=24), unsafe_allow_html=True)

# -----------------------------
# Report page
# -----------------------------
elif page == "Report":
    st.subheader("Report")
    if not st.session_state.health:
        st.info("Run a check first from the left sidebar.")
    else:
        devices = st.session_state.devices
        tables = st.session_state.tables
        findings = st.session_state.findings
        accepted = set(st.session_state.accepted_findings)
        adjusted = recompute_device_health(devices, findings, accepted)
        render_metrics(st.session_state.health, adjusted, tables)

        active = adjusted.get("active_findings", [])
        if active:
            red = sum(1 for f in active if f.get("Severity") == "RED")
            yellow = sum(1 for f in active if f.get("Severity") == "YELLOW")
            summary = f"FabricOps found {red} serious item(s) and {yellow} item(s) that need attention. Open each finding for a simple explanation and technical evidence."
        else:
            summary = "FabricOps did not find active problems after accepted findings for this run."
        st.markdown(f"<div class='card'><b>Plain-English summary</b><br><span class='muted'>{esc(summary)}</span></div>", unsafe_allow_html=True)

        st.markdown("### Findings first")
        accepted = render_findings(findings, bool(st.session_state.get("show_config_hints", True)))
        adjusted = recompute_device_health(devices, findings, accepted)

        st.markdown("### Device health")
        render_device_tiles(devices, adjusted["status_by_device"], tables)

        st.markdown("### Device details")
        render_device_details(devices, tables, adjusted["status_by_device"])

        st.markdown("### Expert details")
        expert_sections = [
            ("Interface Status", "interfaces", ["Device", "Interface", "Status", "VLAN", "Mode", "Speed", "Description"]),
            ("VLANs", "vlans", ["Device", "VLAN", "Name", "Status", "Interfaces"]),
            ("BGP Neighbors", "bgp", ["Device", "VRF", "Neighbor", "ASN", "State", "Prefixes", "Uptime"]),
            ("EVPN Neighbors", "evpn", ["Device", "VRF", "Neighbor", "ASN", "State", "Prefixes", "Uptime"]),
            ("OSPF", "ospf", None),
            ("MLAG", "mlag", None),
            ("Port-Channels", "port_channels", None),
            ("LLDP Edges", "lldp", ["Device", "Port", "Neighbor", "Port ID", "Link Type", "Status"]),
            ("Command Failures", "command_failures", None),
            ("Raw Command Output", "command_outputs", None),
        ]
        for title, key, cols in expert_sections:
            rows = friendly_lldp_rows(tables.get("lldp", [])) if key == "lldp" else tables.get(key, [])
            with st.expander(f"{title} ({len(rows)} rows)", expanded=False):
                st.markdown(table_html(rows, columns=cols, max_rows=500 if key != "command_outputs" else 120), unsafe_allow_html=True)

        report = build_html_report(st.session_state.health, adjusted.get("active_findings", []), st.session_state.recommendations, devices, tables)
        st.download_button("Download HTML report", data=report, file_name=f"fabricops_report_{int(time.time())}.html", mime="text/html")
        st.download_button("Download JSON report", data=json.dumps({"health": st.session_state.health, "findings": findings, "tables": tables}, indent=2), file_name=f"fabricops_report_{int(time.time())}.json", mime="application/json")

# -----------------------------
# Topology page
# -----------------------------
elif page == "Topology":
    st.subheader("Topology")
    if not st.session_state.tables:
        st.info("Run a check first. Topology is built from LLDP data collected during validation.")
    else:
        devices = st.session_state.devices
        tables = st.session_state.tables
        adjusted = recompute_device_health(devices, st.session_state.findings, set(st.session_state.accepted_findings))
        st.markdown("<div class='card'><b>Interactive topology</b><br><span class='muted'>Drag devices to reposition them. Save layout stores the placement in this browser. Reset layout returns to FabricOps auto layout.</span></div>", unsafe_allow_html=True)
        st_html(build_topology_html(devices, tables, adjusted["status_by_device"], style), height=980, scrolling=True)
        st.markdown("### LLDP edges")
        st.markdown(table_html(friendly_lldp_rows(tables.get("lldp", [])), ["Device", "Port", "Neighbor", "Port ID", "Link Type", "Status"], max_rows=500), unsafe_allow_html=True)
