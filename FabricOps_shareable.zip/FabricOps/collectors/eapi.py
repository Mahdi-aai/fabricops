
from __future__ import annotations
from typing import Any, Dict, List, Tuple
import requests, urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

class EapiResult(dict):
    pass

def normalize_transport(protocol: str, port: int, auto_fix: bool = True) -> Tuple[str, int, str]:
    protocol = (protocol or 'https').lower().strip()
    port = int(port or (443 if protocol == 'https' else 80))
    note = ''
    if auto_fix:
        if protocol == 'http' and port == 443:
            protocol = 'https'
            note = 'Auto-fixed eAPI transport from http:443 to https:443.'
        elif protocol == 'https' and port == 80:
            protocol = 'http'
            note = 'Auto-fixed eAPI transport from https:80 to http:80.'
    return protocol, port, note

def run_show_commands(host: str, username: str, password: str, commands: List[str], protocol: str='https', port: int=443, verify_ssl: bool=False, timeout: int=45, auto_fix_transport: bool=True) -> Dict[str, Any]:
    if not host:
        return {'reachable': False, 'error': 'Missing management IP.', 'outputs': {}, 'output_formats': {}, 'command_status': []}
    protocol, port, transport_note = normalize_transport(protocol, port, auto_fix_transport)
    endpoint = f"{protocol}://{host}:{port}/command-api"

    # First try bulk JSON because it is fast and returns structured data.
    bulk = _post(endpoint, username, password, commands, 'json', verify_ssl, timeout)
    if bulk['http_error']:
        # HTTP failures are transport/auth/reachability problems; do not hide them.
        return {'reachable': False, 'endpoint': endpoint, 'error': bulk['error'], 'outputs': {}, 'output_formats': {}, 'command_status': [], 'transport_note': transport_note, 'raw': bulk.get('raw')}

    body = bulk.get('body') or {}
    if isinstance(body, dict) and isinstance(body.get('result'), list) and not body.get('error'):
        outputs = {cmd: body['result'][i] if i < len(body['result']) else None for i, cmd in enumerate(commands)}
        return {'reachable': True, 'endpoint': endpoint, 'error': '', 'outputs': outputs, 'output_formats': {cmd: 'json' for cmd in commands}, 'command_status': [{'Command': c, 'Status': 'OK', 'Format': 'json', 'Error': ''} for c in commands], 'transport_note': transport_note, 'raw': body}

    # If bulk failed because one command does not support JSON, run commands one-by-one.
    outputs: Dict[str, Any] = {}
    output_formats: Dict[str, str] = {}
    status_rows: List[Dict[str, Any]] = []
    any_success = False
    for cmd in commands:
        one = _post(endpoint, username, password, [cmd], 'json', verify_ssl, timeout)
        if not one['http_error'] and isinstance(one.get('body'), dict) and isinstance(one['body'].get('result'), list) and not one['body'].get('error'):
            outputs[cmd] = one['body']['result'][0] if one['body']['result'] else None
            output_formats[cmd] = 'json'
            status_rows.append({'Command': cmd, 'Status': 'OK', 'Format': 'json', 'Error': ''})
            any_success = True
            continue
        # Fallback to text for commands that do not support JSON.
        text = _post(endpoint, username, password, [cmd], 'text', verify_ssl, timeout)
        if not text['http_error'] and isinstance(text.get('body'), dict) and isinstance(text['body'].get('result'), list) and not text['body'].get('error'):
            outputs[cmd] = text['body']['result'][0] if text['body']['result'] else ''
            output_formats[cmd] = 'text'
            status_rows.append({'Command': cmd, 'Status': 'OK', 'Format': 'text', 'Error': ''})
            any_success = True
        else:
            err = text.get('error') or one.get('error') or str(text.get('body') or one.get('body'))[:500]
            outputs[cmd] = None
            output_formats[cmd] = 'failed'
            status_rows.append({'Command': cmd, 'Status': 'FAILED', 'Format': 'none', 'Error': err})
    return {'reachable': any_success, 'endpoint': endpoint, 'error': '' if any_success else 'All eAPI commands failed.', 'outputs': outputs, 'output_formats': output_formats, 'command_status': status_rows, 'transport_note': transport_note, 'raw': body}

def _post(endpoint: str, username: str, password: str, commands: List[str], fmt: str, verify_ssl: bool, timeout: int) -> Dict[str, Any]:
    payload = {'jsonrpc':'2.0','method':'runCmds','params': {'version': 1, 'cmds': commands, 'format': fmt, 'timestamps': False}, 'id':'mav-fabricops-ai'}
    try:
        r = requests.post(endpoint, json=payload, auth=(username, password), headers={'Content-Type':'application/json','Accept':'application/json'}, verify=verify_ssl, timeout=timeout)
        text = r.text
        if r.status_code >= 400:
            return {'http_error': True, 'error': f"{r.status_code} {r.reason}: {text[:700]}", 'raw': text}
        try:
            return {'http_error': False, 'body': r.json(), 'raw': text}
        except Exception:
            return {'http_error': False, 'body': text, 'raw': text}
    except Exception as exc:
        return {'http_error': True, 'error': str(exc), 'raw': ''}
