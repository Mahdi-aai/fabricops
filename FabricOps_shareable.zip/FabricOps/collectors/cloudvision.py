
from __future__ import annotations
import json
import re
from typing import Any, Dict, List, Optional
import requests, urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

class CloudVisionClient:
    def __init__(self, base_url: str, username: str, password: str, verify_ssl: bool = False, timeout: int = 30):
        self.base_url = base_url.rstrip('/')
        self.username = username
        self.password = password
        self.verify_ssl = verify_ssl
        self.timeout = timeout
        self.session = requests.Session()
        self.session.verify = verify_ssl
        self.session_token: Optional[str] = None

    def login(self) -> str:
        url = f"{self.base_url}/cvpservice/login/authenticate.do"
        r = self.session.post(url, auth=(self.username, self.password), headers={'Accept':'application/json'}, timeout=self.timeout, verify=self.verify_ssl)
        r.raise_for_status()
        data = _safe_json(r)
        token = _find_token(data)
        if not token:
            raise RuntimeError(f"CloudVision login succeeded but no sessionId was found. Response: {str(data)[:800]}")
        self.session_token = token
        self.session.headers.update({'Authorization': f'Bearer {token}', 'Cookie': f'access_token={token}', 'Accept':'application/json'})
        return token

    def get_device_inventory(self) -> List[Dict[str, Any]]:
        return self._get_streaming_json('/api/resources/inventory/v1/Device/all')

    def get_provisioned_devices(self) -> List[Dict[str, Any]]:
        return self._get_streaming_json('/api/resources/inventory/v1/ProvisionedDevice/all')

    def _get_streaming_json(self, path: str) -> List[Dict[str, Any]]:
        if not self.session_token:
            self.login()
        r = self.session.get(f"{self.base_url}{path}", timeout=self.timeout, verify=self.verify_ssl)
        r.raise_for_status()
        return decode_cloudvision_records(r.text)

def _safe_json(response: requests.Response) -> Any:
    try: return response.json()
    except Exception:
        try: return json.loads(response.text)
        except Exception: return response.text

def _find_token(value: Any, depth: int = 0) -> Optional[str]:
    if depth > 8 or value is None: return None
    if isinstance(value, str):
        try: return _find_token(json.loads(value), depth+1)
        except Exception: return None
    if isinstance(value, dict):
        for key in ('sessionId','session_id','token','access_token'):
            token = value.get(key)
            if isinstance(token, str) and token.strip(): return token.strip()
        for child in value.values():
            found = _find_token(child, depth+1)
            if found: return found
    if isinstance(value, list):
        for child in value:
            found = _find_token(child, depth+1)
            if found: return found
    return None

def decode_cloudvision_records(raw: str) -> List[Dict[str, Any]]:
    if not raw: return []
    try:
        p = json.loads(raw)
        if isinstance(p, list): return [x for x in p if isinstance(x, dict)]
        if isinstance(p, dict):
            if isinstance(p.get('data'), list): return [x for x in p['data'] if isinstance(x, dict)]
            return [p]
    except Exception: pass
    records, depth, start, in_string, escaped = [], 0, -1, False, False
    for i, ch in enumerate(raw):
        if in_string:
            if escaped: escaped = False
            elif ch == '\\': escaped = True
            elif ch == '"': in_string = False
            continue
        if ch == '"': in_string = True
        elif ch == '{':
            if depth == 0: start = i
            depth += 1
        elif ch == '}':
            depth -= 1
            if depth == 0 and start >= 0:
                try:
                    item = json.loads(raw[start:i+1])
                    if isinstance(item, dict): records.append(item)
                except Exception: pass
                start = -1
    return records

def join_inventory(device_records: List[Dict[str, Any]], provisioned_records: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    device_values = [_record_value(r) for r in device_records]
    provisioned_values = [_record_value(r) for r in provisioned_records]
    by_id = {str(x.get('key',{}).get('deviceId') or x.get('deviceId') or x.get('serialNumber') or ''): x for x in provisioned_values if isinstance(x, dict)}
    devices = []
    for record in device_values:
        if not isinstance(record, dict): continue
        device_id = str(record.get('key',{}).get('deviceId') or record.get('deviceId') or record.get('serialNumber') or '')
        p = by_id.get(device_id, {})
        hostname = str(record.get('hostname') or record.get('fqdn') or device_id or 'unknown')
        host = _scalar(p.get('ipAddress')) or _scalar(p.get('managementIp')) or _scalar(record.get('primaryManagementIp')) or _scalar(record.get('systemIpAddress')) or _scalar(record.get('ipAddress'))
        if hostname == 'unknown' and not device_id: continue
        devices.append({
            'name': hostname, 'role': infer_role(hostname), 'host': host, 'device_id': device_id,
            'serial': record.get('serialNumber') or device_id, 'fqdn': record.get('fqdn') or '',
            'model': record.get('modelName') or record.get('model') or '',
            'software_version': record.get('softwareVersion') or record.get('version') or '',
            'boot_time': record.get('bootTime') or '', 'streaming_status': record.get('streamingStatus') or 'UNKNOWN',
            'cloudvision_active': record.get('streamingStatus') == 'STREAMING_STATUS_ACTIVE',
            'provisioning_status': p.get('status') or p.get('provisioningStatus') or '',
            'provisioning_group': p.get('provisioningGroupName') or '',
        })
    return sorted(devices, key=lambda d: _device_sort_key(d.get('name')))

def infer_role(hostname: str) -> str:
    n = hostname.lower()
    if 'router' in n: return 'router'
    if 'spine' in n: return 'spine'
    if 'memleaf' in n: return 'memleaf'
    if 'border' in n: return 'border-leaf'
    if 'leaf' in n: return 'leaf'
    if 'host' in n: return 'host'
    return 'unknown'


ROLE_ORDER = {'router': 0, 'spine': 1, 'leaf': 2, 'memleaf': 3, 'host': 4, 'unknown': 9}


def _natural_key(value: Any) -> tuple:
    text = str(value or '').lower()
    parts = re.split(r'(\d+)', text)
    return tuple(int(p) if p.isdigit() else p for p in parts)


def _device_sort_key(name: Any) -> tuple:
    role = infer_role(str(name or ''))
    if role == 'border-leaf':
        role = 'leaf'
    return (ROLE_ORDER.get(role, 9), _natural_key(name))


def _record_value(record: Dict[str, Any]) -> Any:
    return record.get('result',{}).get('value') or record.get('value') or record

def _scalar(value: Any) -> str:
    if value is None: return ''
    if isinstance(value, (str,int,float)): return str(value)
    if isinstance(value, dict) and 'value' in value: return str(value['value'])
    return ''
