@echo off
cd /d "%~dp0"
py -m venv .venv
if errorlevel 1 goto failed
.venv\Scripts\python.exe -m pip install -r requirements.txt
if errorlevel 1 goto failed
.venv\Scripts\python.exe -m streamlit run app.py
pause
exit /b
:failed
echo Unable to start. Install Python 3.11 or newer and check your internet connection.
pause
exit /b 1
